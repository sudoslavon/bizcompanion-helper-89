
import { useEffect } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useToast } from "@/components/ui/use-toast";
import { Form, FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { CheckCircle, BadgeCheck, Package, Rocket, BrainCircuit, Settings } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const formSchema = z.object({
  companyName: z.string().min(2, { message: "Введите название компании" }),
  fullName: z.string().min(2, { message: "Введите ФИО" }),
  phone: z.string().min(10, { message: "Введите корректный номер телефона" }),
  email: z.string().email({ message: "Введите корректный email" }),
  site: z.string().optional(),
  inn: z.string().min(10, { message: "Введите корректный ИНН" }),
  businessType: z.string().min(1, { message: "Укажите тип бизнеса" }),
  serviceTypes: z.string().array().min(1, { message: "Выберите хотя бы один тип услуги" }),
  experience: z.string().min(1, { message: "Укажите опыт работы" }),
  portfolio: z.string().optional(),
  description: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const ForContractors = () => {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyName: "",
      fullName: "",
      phone: "",
      email: "",
      site: "",
      inn: "",
      businessType: "",
      serviceTypes: [],
      experience: "",
      portfolio: "",
      description: "",
    },
  });
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  function onSubmit(data: FormValues) {
    console.log(data);
    toast({
      title: "Заявка на аккредитацию отправлена",
      description: "Мы свяжемся с вами в ближайшее время",
    });
    form.reset();
  }

  const steps = [
    {
      title: "Подайте заявку",
      description: "Заполните форму на сайте, указав свои компетенции и портфолио",
    },
    {
      title: "Пройдите проверку",
      description: "Мы проверим вашу компанию и оценим качество предоставляемых услуг",
    },
    {
      title: "Заключите договор",
      description: "После успешной проверки мы заключим с вами партнерский договор",
    },
    {
      title: "Получайте заказы",
      description: "Мы будем направлять к вам клиентов и обеспечивать стабильный поток заказов",
    },
  ];

  const serviceTypes = [
    {
      id: "packaging",
      label: "Упаковка бизнеса",
      description: "Создание сайтов, оформление соцсетей, брендирование",
      icon: <Package className="h-6 w-6 text-brand-blue" />,
    },
    {
      id: "promotion",
      label: "Продвижение",
      description: "Настройка таргетированной и контекстной рекламы",
      icon: <Rocket className="h-6 w-6 text-brand-blue" />,
    },
    {
      id: "ai",
      label: "Внедрение AI",
      description: "Разработка и внедрение нейросетевых решений",
      icon: <BrainCircuit className="h-6 w-6 text-brand-blue" />,
    },
    {
      id: "planning",
      label: "Организационное планирование",
      description: "Разработка бизнес-планов и оргструктур",
      icon: <Settings className="h-6 w-6 text-brand-blue" />,
    },
  ];

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <section className="bg-gradient-to-b from-blue-50 to-white py-12 md:py-24 relative">
          <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/f/f2/Coat_of_Arms_of_the_Russian_Federation.svg" 
              alt="Герб РФ" 
              className="h-[60%] w-auto object-contain"
            />
          </div>
          
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center mb-16">
              <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium mb-4">
                Для исполнителей
              </span>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Станьте аккредитованным исполнителем <span className="text-brand-blue">Господдержка.Бизнес</span>
              </h1>
              <p className="text-lg text-gray-600">
                Получайте стабильный поток клиентов и развивайте свой бизнес вместе с нами. 
                Мы делаем digital-услуги доступнее и помогаем найти новых клиентов.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-16 items-start">
              <div className="space-y-8">
                <div>
                  <h2 className="text-2xl font-bold mb-6 text-gray-900">Как стать исполнителем</h2>
                  <div className="space-y-6">
                    {steps.map((step, index) => (
                      <div key={index} className="flex gap-4">
                        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-brand-blue text-white flex items-center justify-center font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                          <p className="text-gray-600">{step.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="bg-white p-6 rounded-xl shadow-sm">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <BadgeCheck className="h-6 w-6 text-brand-green" />
                    Преимущества сотрудничества
                  </h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-600">Стабильный поток клиентов без затрат на рекламу</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-600">Повышение престижа благодаря официальной аккредитации</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-600">Работа с государственными программами поддержки</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-600">Обучение и постоянное развитие в рамках партнерской программы</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-600">Оперативная оплата по факту выполнения работ</p>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {serviceTypes.map((service) => (
                    <Card key={service.id} className="border-l-4 border-l-brand-blue">
                      <CardContent className="p-4">
                        <div className="flex gap-3 items-start">
                          {service.icon}
                          <div>
                            <h4 className="font-medium text-gray-900">{service.label}</h4>
                            <p className="text-xs text-gray-600 mt-1">{service.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
              
              <div className="glass-card p-6 md:p-8 rounded-xl shadow-sm">
                <h2 className="text-2xl font-bold mb-6 text-gray-900">Заявка на аккредитацию</h2>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Название компании / ИП</FormLabel>
                          <FormControl>
                            <Input placeholder="ООО 'Компания'" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ФИО руководителя/ответственного лица</FormLabel>
                          <FormControl>
                            <Input placeholder="Иванов Иван Иванович" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Телефон</FormLabel>
                            <FormControl>
                              <Input placeholder="+7 (___) ___-__-__" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="example@mail.ru" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="site"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Сайт</FormLabel>
                            <FormControl>
                              <Input placeholder="https://yoursite.ru" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="inn"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ИНН</FormLabel>
                            <FormControl>
                              <Input placeholder="1234567890" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="businessType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Форма предпринимательства</FormLabel>
                          <FormControl>
                            <select 
                              className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                              {...field}
                            >
                              <option value="">Выберите форму</option>
                              <option value="ООО">ООО</option>
                              <option value="ИП">ИП</option>
                              <option value="Самозанятый">Самозанятый</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="serviceTypes"
                      render={() => (
                        <FormItem>
                          <FormLabel>Направления деятельности</FormLabel>
                          <div className="space-y-2">
                            {serviceTypes.map((service) => (
                              <div key={service.id} className="flex items-center space-x-2">
                                <input
                                  type="checkbox"
                                  id={service.id}
                                  value={service.id}
                                  onChange={(e) => {
                                    const currentValues = form.getValues("serviceTypes") || [];
                                    if (e.target.checked) {
                                      form.setValue("serviceTypes", [...currentValues, e.target.value]);
                                    } else {
                                      form.setValue(
                                        "serviceTypes",
                                        currentValues.filter((value) => value !== e.target.value)
                                      );
                                    }
                                  }}
                                  className="h-4 w-4 rounded border-gray-300 text-brand-blue focus:ring-brand-blue"
                                />
                                <label htmlFor={service.id} className="text-sm font-medium text-gray-700">
                                  {service.label}
                                </label>
                              </div>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="experience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Опыт работы в данной сфере</FormLabel>
                          <FormControl>
                            <select 
                              className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                              {...field}
                            >
                              <option value="">Выберите опыт работы</option>
                              <option value="less-1">Менее 1 года</option>
                              <option value="1-3">От 1 до 3 лет</option>
                              <option value="3-5">От 3 до 5 лет</option>
                              <option value="more-5">Более 5 лет</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="portfolio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ссылка на портфолио</FormLabel>
                          <FormControl>
                            <Input placeholder="https://portfolio.ru" {...field} />
                          </FormControl>
                          <FormDescription>
                            Укажите ссылку на портфолио или прикрепите презентацию
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>О вашей компании и услугах</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Расскажите подробнее о вашей компании и предоставляемых услугах" 
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-4">
                      <p className="text-xs text-gray-500">
                        Нажимая на кнопку, вы соглашаетесь на сбор и обработку персональных данных
                      </p>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-brand-blue hover:bg-brand-blue/90"
                      >
                        Отправить заявку на аккредитацию
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default ForContractors;
