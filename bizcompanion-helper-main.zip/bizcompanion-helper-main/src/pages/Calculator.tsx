
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Calculator as CalculatorIcon, 
  Landmark, 
  Building, 
  Send,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const Calculator = () => {
  const navigate = useNavigate();
  const [budget, setBudget] = useState<number>(50000);
  const [service, setService] = useState<string>("neuro-content");
  const [compensationPercent, setCompensationPercent] = useState<number>(40);
  const [compensationAmount, setCompensationAmount] = useState<number>(0);
  const [isAnimating, setIsAnimating] = useState(true);
  const [showSuccess, setShowSuccess] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  // Соответствие услуг и процентов компенсации
  const serviceCompensation: Record<string, number> = {
    "neuro-content": 40,
    "ai-targeting": 30,
    "landing-pages": 50,
    "analytics": 45,
  };

  const serviceNames: Record<string, string> = {
    "neuro-content": "Нейроконтент",
    "ai-targeting": "AI-таргетинг",
    "landing-pages": "Лендинги",
    "analytics": "Бизнес-аналитика",
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    
    const timer = setTimeout(() => {
      setIsAnimating(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Обновление процента компенсации при изменении услуги
    setCompensationPercent(serviceCompensation[service]);
  }, [service]);

  useEffect(() => {
    // Расчет суммы компенсации
    const compensation = (budget * compensationPercent) / 100;
    setCompensationAmount(compensation);
  }, [budget, compensationPercent]);

  const handleBudgetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    setBudget(isNaN(value) ? 0 : value);
  };

  const handleServiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setService(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccess(true);
    
    // Имитация отправки формы
    setTimeout(() => {
      navigate('/chat');
    }, 3000);
  };

  const faqItems = [
    {
      question: "Какие документы нужны для получения компенсации?",
      answer: "Для получения компенсации вам потребуются: свидетельство о регистрации ИП/ООО, выписка из ЕГРЮЛ/ЕГРИП не старше 30 дней, документ, подтверждающий статус субъекта МСП, договор на оказание услуг, акт выполненных работ и документ, подтверждающий оплату услуг."
    },
    {
      question: "Сколько времени занимает процесс получения компенсации?",
      answer: "В среднем процесс получения компенсации занимает от 30 до 60 дней с момента подачи всех необходимых документов. Это включает в себя проверку документов (10-15 дней), рассмотрение заявки комиссией (15-20 дней) и перечисление средств (5-15 дней)."
    },
    {
      question: "Какие услуги подпадают под программу компенсации?",
      answer: "Под программу компенсации подпадают следующие услуги: создание и продвижение сайтов, настройка и ведение рекламных кампаний, разработка мобильных приложений, внедрение CRM-систем, услуги по аналитике данных, нейромаркетинг и другие цифровые сервисы. Полный перечень услуг можно получить у наших специалистов."
    },
    {
      question: "Есть ли ограничения по сумме компенсации?",
      answer: "Да, существуют ограничения по максимальной сумме компенсации. В рамках программы 'Цифровизация-2024' максимальная сумма компенсации составляет 500 000 рублей в год на одну компанию. Для программы 'МСП Технологии' - до 300 000 рублей, а для программы 'Инновации для бизнеса' - до 1 000 000 рублей."
    },
    {
      question: "Что делать, если мне отказали в компенсации?",
      answer: "Если вам отказали в компенсации, вы можете: запросить официальную причину отказа, устранить указанные недостатки, подать заявку повторно или обжаловать решение. Наши специалисты помогут вам разобраться с причинами отказа и подготовить все необходимые документы для повторной подачи заявки."
    }
  ];

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className={`transition-all duration-500 ${isAnimating ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
            
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Рассчитайте свою выгоду
              </h1>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Узнайте, сколько вы можете сэкономить на digital-продвижении с помощью государственной поддержки для малого и среднего бизнеса
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
              <div className="glass-card p-6 md:p-8 rounded-xl">
                <div className="flex items-center mb-6">
                  <div className="p-3 bg-brand-blue/10 rounded-lg mr-4">
                    <CalculatorIcon className="w-8 h-8 text-brand-blue" />
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900">
                    Калькулятор компенсации
                  </h2>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Выберите услугу:
                    </label>
                    <select
                      value={service}
                      onChange={handleServiceChange}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                    >
                      <option value="neuro-content">Нейроконтент</option>
                      <option value="ai-targeting">AI-таргетинг</option>
                      <option value="landing-pages">Лендинги</option>
                      <option value="analytics">Бизнес-аналитика</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Бюджет на услугу (руб.):
                    </label>
                    <input
                      type="number"
                      min="10000"
                      max="2000000"
                      step="10000"
                      value={budget}
                      onChange={handleBudgetChange}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                    />
                    <input
                      type="range"
                      min="10000"
                      max="1000000"
                      step="10000"
                      value={budget}
                      onChange={handleBudgetChange}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-4"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>10 тыс.</span>
                      <span>1 млн.</span>
                    </div>
                  </div>

                  <div className="bg-brand-blue/5 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-700">Процент компенсации:</span>
                      <Badge className="bg-brand-green text-white">
                        {compensationPercent}%
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Сумма возмещения:</span>
                      <span className="text-xl font-bold text-brand-blue">
                        {compensationAmount.toLocaleString('ru-RU')} ₽
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className={`glass-card p-6 md:p-8 rounded-xl relative overflow-hidden ${showSuccess ? 'bg-brand-green/10' : ''}`}>
                {!showSuccess ? (
                  <>
                    <div className="flex items-center mb-6">
                      <div className="p-3 bg-brand-blue/10 rounded-lg mr-4">
                        <Send className="w-6 h-6 text-brand-blue" />
                      </div>
                      <h2 className="text-xl font-semibold text-gray-900">
                        Оставить заявку
                      </h2>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Ваше имя:
                        </label>
                        <input
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          required
                          placeholder="Иван Петров"
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Номер телефона:
                        </label>
                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          required
                          placeholder="+7 (999) 123-45-67"
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Тип организации:
                        </label>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="border border-gray-300 rounded-md p-4 cursor-pointer hover:border-brand-blue transition-colors">
                            <div className="flex items-center">
                              <Building className="w-5 h-5 text-gray-500 mr-2" />
                              <span>ООО / АО</span>
                            </div>
                          </div>
                          <div className="border border-gray-300 rounded-md p-4 cursor-pointer hover:border-brand-blue transition-colors">
                            <div className="flex items-center">
                              <Landmark className="w-5 h-5 text-gray-500 mr-2" />
                              <span>ИП / СЗ</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center mb-4">
                          <input 
                            id="terms" 
                            type="checkbox" 
                            required
                            className="h-4 w-4 text-brand-blue border-gray-300 rounded focus:ring-brand-blue"
                          />
                          <label htmlFor="terms" className="ml-2 block text-sm text-gray-600">
                            Я согласен на обработку персональных данных
                          </label>
                        </div>
                      </div>

                      <Button 
                        type="submit"
                        className="w-full bg-brand-blue hover:bg-brand-blue/90"
                      >
                        Получить бесплатную консультацию
                      </Button>

                      <p className="text-xs text-gray-500 text-center">
                        Мы перезвоним вам в течение 30 минут в рабочее время (9:00 - 18:00 МСК)
                      </p>
                    </form>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8">
                    <div className="w-16 h-16 bg-brand-green/20 flex items-center justify-center rounded-full mb-6">
                      <Check className="w-8 h-8 text-brand-green" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2 text-center">
                      Заявка успешно отправлена!
                    </h3>
                    <p className="text-gray-600 text-center mb-6">
                      Наш специалист свяжется с вами в ближайшее время для уточнения деталей и подготовки персонального предложения.
                    </p>
                    <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                      <div className="animate-pulse bg-brand-green h-2 rounded-full w-full"></div>
                    </div>
                    <p className="text-sm text-gray-500">
                      Перенаправление на страницу чата...
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 md:p-8 mb-12 border border-gray-100 shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Часто задаваемые вопросы
              </h2>
              
              <Accordion type="single" collapsible className="w-full">
                {faqItems.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left font-medium">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600">{item.answer}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>

            <div className="bg-brand-blue/5 rounded-xl p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-3">
                    Остались вопросы?
                  </h2>
                  <p className="text-gray-600 mb-6 md:mb-0">
                    Наши специалисты готовы ответить на все ваши вопросы и помочь с оформлением заявки
                  </p>
                </div>
                <Button 
                  asChild
                  className="bg-brand-blue hover:bg-brand-blue/90"
                >
                  <a href="tel:+78001234567">
                    Позвонить: 8 (800) 123-45-67
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default Calculator;
