
import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { 
  ArrowLeft, 
  BrainCircuit, 
  Target, 
  Lightbulb, 
  LineChart, 
  CheckCircle, 
  X,
  Percent,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Calculator from "@/components/ui/Calculator";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

interface Service {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  compensationPercent: number;
  programName: string;
  longDescription: string;
  features: string[];
  requirements: string[];
  examples: { title: string; image: string; description: string }[];
}

const services: Service[] = [
  {
    id: "neuro-content",
    title: "Нейроконтент",
    description: "Автоматическая генерация постов, сторис и email-рассылок с помощью передовых нейросетей. Создавайте контент для соцсетей в 10 раз быстрее.",
    icon: <BrainCircuit className="w-10 h-10 text-brand-blue" />,
    compensationPercent: 40,
    programName: "Цифровизация-2024",
    longDescription: "Нейроконтент — это инновационное решение для автоматического создания текстов, изображений и видео с помощью искусственного интеллекта. Технология позволяет значительно сократить время на разработку контента для социальных сетей, email-рассылок и других маркетинговых материалов, повышая при этом их эффективность и качество. Наш сервис использует передовые модели нейросетей, обученные на миллионах примеров успешного контента в различных отраслях бизнеса.",
    features: [
      "Генерация постов для социальных сетей (ВКонтакте, Одноклассники, Telegram)",
      "Создание продающих текстов для email-рассылок",
      "Генерация изображений для публикаций и рекламы",
      "Персонализация контента под вашу целевую аудиторию",
      "Адаптация тональности и стиля под бренд компании",
      "Автоматическое составление контент-плана на месяц",
      "Аналитика эффективности опубликованного контента"
    ],
    requirements: [
      "Наличие статуса субъекта МСП",
      "Регистрация бизнеса не менее 6 месяцев назад",
      "Отсутствие задолженности по налогам и сборам",
      "Наличие действующих социальных сетей или сайта компании"
    ],
    examples: [
      {
        title: "Кейс: Сеть кофеен «Кофейня»",
        image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?w=600&auto=format&fit=crop&q=80",
        description: "Увеличение вовлеченности подписчиков на 47% за 2 месяца с помощью нейроконтента. Компенсация составила 38 000 рублей."
      },
      {
        title: "Кейс: Автосервис «АвтоПлюс»",
        image: "https://images.unsplash.com/photo-1519752594763-3a6147286793?w=600&auto=format&fit=crop&q=80",
        description: "Рост конверсии из социальных сетей на 32% за счет персонализированного контента. Компенсация составила 42 000 рублей."
      }
    ]
  },
  {
    id: "ai-targeting",
    title: "AI-таргетинг",
    description: "Умная настройка и оптимизация рекламы в социальных сетях с аналитикой в реальном времени. Увеличьте ROAS ваших рекламных кампаний.",
    icon: <Target className="w-10 h-10 text-brand-blue" />,
    compensationPercent: 30,
    programName: "МСП Технологии",
    longDescription: "AI-таргетинг — это современное решение для автоматической настройки и оптимизации рекламных кампаний в социальных сетях и контекстной рекламе с использованием искусственного интеллекта. Технология анализирует поведение пользователей, определяет наиболее перспективные аудитории и автоматически корректирует параметры рекламных кампаний для достижения максимальной эффективности и снижения стоимости привлечения клиентов.",
    features: [
      "Автоматический подбор целевой аудитории на основе AI-анализа",
      "Оптимизация рекламных кампаний в режиме реального времени",
      "Распределение бюджета между площадками для максимального ROI",
      "Автоматическое тестирование различных креативов и текстов",
      "Расширенная аналитика и отчетность по всем каналам",
      "Интеграция с CRM-системами для отслеживания конверсий",
      "Прогнозирование результатов рекламных кампаний"
    ],
    requirements: [
      "Наличие статуса субъекта МСП",
      "Регистрация бизнеса не менее 3 месяцев назад",
      "Наличие действующего сайта или страницы в социальных сетях",
      "Минимальный рекламный бюджет от 30 000 рублей"
    ],
    examples: [
      {
        title: "Кейс: Интернет-магазин «ТехноШоп»",
        image: "https://images.unsplash.com/photo-1534723452862-4c874018d66d?w=600&auto=format&fit=crop&q=80",
        description: "Снижение стоимости привлечения клиента на 42% и рост ROAS на 67% за 1 месяц. Компенсация составила 35 000 рублей."
      },
      {
        title: "Кейс: Салон красоты «Бьюти»",
        image: "https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=600&auto=format&fit=crop&q=80",
        description: "Увеличение количества записей на 53% при том же рекламном бюджете. Компенсация составила 27 000 рублей."
      }
    ]
  },
  {
    id: "landing-pages",
    title: "Лендинги",
    description: "Создание высококонверсионных сайтов с AI-копирайтингом. Готовые шаблоны и быстрый запуск помогут привлечь новых клиентов.",
    icon: <Lightbulb className="w-10 h-10 text-brand-blue" />,
    compensationPercent: 50,
    programName: "Инновации для бизнеса",
    longDescription: "Наш сервис создания лендингов — это комплексное решение для быстрой разработки высококонверсионных посадочных страниц с использованием искусственного интеллекта. Технология автоматически генерирует оптимальную структуру страницы, продающие тексты и подбирает визуальные элементы на основе анализа вашей ниши и целевой аудитории. Готовый лендинг можно запустить в течение нескольких дней без привлечения дорогостоящих специалистов.",
    features: [
      "Более 50 готовых шаблонов лендингов для разных сфер бизнеса",
      "AI-копирайтинг текстов с учетом целевой аудитории",
      "Автоматическая оптимизация для поисковых систем",
      "Адаптивный дизайн для всех устройств",
      "Интеграция форм захвата лидов с CRM-системами",
      "Система A/B-тестирования элементов страницы",
      "Хостинг и техническая поддержка в течение года"
    ],
    requirements: [
      "Наличие статуса субъекта МСП",
      "Регистрация в налоговых органах",
      "Наличие зарегистрированного домена или возможность его регистрации",
      "Предоставление информации о компании и услугах"
    ],
    examples: [
      {
        title: "Кейс: Юридическая компания «ПравоГрад»",
        image: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80",
        description: "Увеличение конверсии лендинга с 1.8% до 5.3% и рост числа заявок в 3 раза. Компенсация составила 45 000 рублей."
      },
      {
        title: "Кейс: Строительная компания «СтройДом»",
        image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600&auto=format&fit=crop&q=80",
        description: "Снижение стоимости привлечения клиента на 57% после запуска нового лендинга. Компенсация составила 52 000 рублей."
      }
    ]
  },
  {
    id: "analytics",
    title: "Бизнес-аналитика",
    description: "Автоматический анализ данных вашего бизнеса с помощью ИИ. Получайте инсайты и рекомендации для принятия важных решений.",
    icon: <LineChart className="w-10 h-10 text-brand-blue" />,
    compensationPercent: 45,
    programName: "МСП Технологии",
    longDescription: "Сервис бизнес-аналитики на базе искусственного интеллекта позволяет автоматически собирать, анализировать и визуализировать данные о вашем бизнесе из различных источников. Система выявляет скрытые закономерности, прогнозирует тренды и предлагает конкретные рекомендации для оптимизации бизнес-процессов, увеличения продаж и снижения затрат без необходимости найма дорогостоящих аналитиков.",
    features: [
      "Сбор и объединение данных из CRM, рекламных кабинетов, сайта и касс",
      "Автоматическая визуализация ключевых метрик бизнеса",
      "Прогнозирование продаж и выявление сезонных колебаний",
      "Сегментация клиентской базы и анализ поведения клиентов",
      "Анализ эффективности маркетинговых каналов",
      "Выявление узких мест в воронке продаж",
      "Еженедельные отчеты с рекомендациями по оптимизации"
    ],
    requirements: [
      "Наличие статуса субъекта МСП",
      "Минимальный срок работы бизнеса — 6 месяцев",
      "Наличие базовых систем учета (CRM, ERP, онлайн-касса)",
      "Готовность предоставить доступ к источникам данных"
    ],
    examples: [
      {
        title: "Кейс: Сеть магазинов «Продукты24»",
        image: "https://images.unsplash.com/photo-1556740738-b6a63e27c4df?w=600&auto=format&fit=crop&q=80",
        description: "Увеличение маржинальности на 12% за счет оптимизации ассортимента на основе данных аналитики. Компенсация составила 48 000 рублей."
      },
      {
        title: "Кейс: Онлайн-школа «Учись легко»",
        image: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=600&auto=format&fit=crop&q=80",
        description: "Снижение оттока клиентов на 35% благодаря выявлению критических точек в клиентском опыте. Компенсация составила 41 000 рублей."
      }
    ]
  }
];

const ServiceDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [service, setService] = useState<Service | null>(null);
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);
    
    const foundService = services.find(s => s.id === id) || null;
    setService(foundService);
    
    const timer = setTimeout(() => {
      setIsAnimating(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [id]);

  if (!service) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Услуга не найдена</h1>
            <p className="text-gray-600 mb-6">
              Извините, запрашиваемая услуга не существует или была удалена.
            </p>
            <Button asChild>
              <Link to="/services">
                Вернуться к списку услуг
              </Link>
            </Button>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <Button 
              asChild
              variant="ghost" 
              className="group mb-8"
            >
              <Link to="/services" className="flex items-center">
                <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
                Назад к услугам
              </Link>
            </Button>

            <div className={`transition-all duration-500 ${isAnimating ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
              <div className="flex flex-col md:flex-row md:items-center gap-4 mb-8">
                <div className="p-4 bg-brand-blue/10 rounded-xl">
                  {service.icon}
                </div>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                    {service.title}
                  </h1>
                  <div className="flex items-center mt-2">
                    <Badge 
                      variant="outline" 
                      className="font-normal border-brand-green/30 text-brand-green flex items-center gap-1.5"
                    >
                      <Percent className="h-3.5 w-3.5" />
                      <span>Компенсация {service.compensationPercent}%</span>
                    </Badge>
                    <span className="ml-3 text-sm text-gray-500">
                      Программа: {service.programName}
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
                <div className="lg:col-span-2">
                  <p className="text-gray-700 mb-8 text-lg leading-relaxed">
                    {service.longDescription}
                  </p>

                  <Tabs defaultValue="features">
                    <TabsList className="mb-6">
                      <TabsTrigger value="features">Возможности</TabsTrigger>
                      <TabsTrigger value="requirements">Требования</TabsTrigger>
                      <TabsTrigger value="examples">Примеры работ</TabsTrigger>
                    </TabsList>
                    <TabsContent value="features" className="space-y-6 animate-fade-in">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">
                        Что включено в услугу
                      </h2>
                      <ul className="space-y-3">
                        {service.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-brand-green mr-3 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </TabsContent>
                    <TabsContent value="requirements" className="space-y-6 animate-fade-in">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">
                        Требования для получения компенсации
                      </h2>
                      <ul className="space-y-3">
                        {service.requirements.map((requirement, index) => (
                          <li key={index} className="flex items-start">
                            <div className="h-5 w-5 text-brand-blue mr-3 flex-shrink-0 mt-0.5">
                              {index + 1}.
                            </div>
                            <span className="text-gray-700">{requirement}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="mt-8 p-4 bg-brand-blue/5 rounded-lg border border-brand-blue/10">
                        <p className="text-sm text-gray-600">
                          Примечание: мы не гарантируем одобрение компенсации, так как решение принимается органами МСП. Однако наш опыт и правильное оформление документов значительно повышают шансы на положительное решение.
                        </p>
                      </div>
                    </TabsContent>
                    <TabsContent value="examples" className="space-y-8 animate-fade-in">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">
                        Примеры успешных проектов
                      </h2>
                      <div className="space-y-8">
                        {service.examples.map((example, index) => (
                          <div key={index} className="glass-card p-6 rounded-xl">
                            <div className="flex flex-col md:flex-row gap-6">
                              <div className="md:w-1/3">
                                <img 
                                  src={example.image} 
                                  alt={example.title}
                                  className="w-full h-48 object-cover rounded-lg"
                                />
                              </div>
                              <div className="md:w-2/3">
                                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                                  {example.title}
                                </h3>
                                <p className="text-gray-600 mb-4">
                                  {example.description}
                                </p>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="group"
                                >
                                  <span className="flex items-center">
                                    Подробнее о кейсе
                                    <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                                  </span>
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>

                <div className="glass-card p-6 rounded-xl h-fit">
                  <Calculator />
                </div>
              </div>

              <div className="bg-brand-blue/5 rounded-xl p-6 md:p-8 mb-12">
                <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-3">
                      Готовы начать проект?
                    </h2>
                    <p className="text-gray-600 mb-6 md:mb-0">
                      Заполните заявку прямо сейчас и получите бесплатную консультацию по вашему проекту
                    </p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button asChild variant="outline">
                      <Link to="/calculator">
                        Рассчитать компенсацию
                      </Link>
                    </Button>
                    <Button asChild className="bg-brand-blue hover:bg-brand-blue/90">
                      <Link to="/chat">
                        Оставить заявку
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-6">
                  Похожие услуги
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {services
                    .filter(s => s.id !== service.id)
                    .slice(0, 3)
                    .map(s => (
                      <Link 
                        key={s.id} 
                        to={`/services/${s.id}`}
                        className="glass-card rounded-xl p-6 hover-lift"
                      >
                        <div className="flex items-start">
                          <div className="p-3 bg-brand-blue/10 rounded-lg mr-4">
                            {s.icon}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">
                              {s.title}
                            </h3>
                            <div className="flex items-center">
                              <Percent className="h-3.5 w-3.5 text-brand-green mr-1" />
                              <span className="text-sm text-brand-green font-medium">
                                Компенсация {s.compensationPercent}%
                              </span>
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default ServiceDetails;
