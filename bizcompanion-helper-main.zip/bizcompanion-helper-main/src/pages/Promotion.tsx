
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Rocket, CheckCircle, Percent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const Promotion = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const services = [
    {
      title: "Настройка таргетированной рекламы",
      description: "Профессиональная настройка рекламы в социальных сетях с точным таргетингом на вашу аудиторию",
      compensationPercent: 50
    },
    {
      title: "Настройка контекстной рекламы",
      description: "Настройка рекламы в поисковых системах Яндекс и Google для привлечения заинтересованных клиентов",
      compensationPercent: 45
    },
    {
      title: "Помощь в закупке рекламы",
      description: "Организация рекламных размещений у пабликов и блогеров с целевой аудиторией",
      compensationPercent: 40
    },
    {
      title: "Разработка контент-плана",
      description: "Создание стратегического плана публикаций для социальных сетей на месяц или квартал",
      compensationPercent: 35
    },
    {
      title: "Съёмка контента",
      description: "Профессиональная фото- и видеосъемка для вашего бизнеса с последующей обработкой",
      compensationPercent: 45
    },
    {
      title: "Помощь с полиграфией",
      description: "Разработка и печать листовок, визиток, каталогов и другой полиграфической продукции",
      compensationPercent: 30
    }
  ];

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <Button 
            asChild
            variant="ghost" 
            className="group mb-8"
          >
            <Link to="/" className="flex items-center">
              <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
              Назад на главную
            </Link>
          </Button>

          <div className="relative mb-12">
            <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/f/f2/Coat_of_Arms_of_the_Russian_Federation.svg" 
                alt="Герб РФ" 
                className="h-[300px] w-auto object-contain"
              />
            </div>
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="bg-brand-blue/10 p-6 rounded-xl">
                  <Rocket className="h-16 w-16 text-brand-blue" />
                </div>
                
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                    Продвижение бизнеса
                  </h1>
                  <p className="text-lg text-gray-700 mb-6 max-w-3xl">
                    Комплексное продвижение бизнеса включает настройку таргетированной и контекстной рекламы, 
                    помощь в закупке рекламы у пабликов и блогеров, разработку контент-плана, 
                    съёмку контента и помощь с полиграфией для эффективного привлечения клиентов.
                  </p>
                  
                  <div className="bg-brand-blue/5 p-4 rounded-lg border border-brand-blue/10 mb-6">
                    <h3 className="font-semibold mb-2">Как получить поддержку:</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Заполните форму на нашем сайте</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Получите консультацию специалиста</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Заключите договор на услуги</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Оформите заявку на компенсацию через портал Госуслуг</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Услуги с господдержкой в категории "Продвижение"
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center text-brand-green">
                    <Percent className="h-4 w-4 mr-1" />
                    <span>Компенсация до {service.compensationPercent}%</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between bg-brand-blue/5 p-8 rounded-xl">
            <div className="md:w-2/3 mb-6 md:mb-0">
              <h3 className="text-xl font-bold mb-2">Готовы начать продвижение вашего бизнеса?</h3>
              <p className="text-gray-600">
                Получите консультацию специалиста и узнайте, как получить компенсацию до 50% затрат
              </p>
            </div>
            <div className="flex gap-4">
              <Button variant="outline">
                <Link to="/calculator">Рассчитать выгоду</Link>
              </Button>
              <Button className="bg-brand-blue hover:bg-brand-blue/90">
                <Link to="/chat">Получить консультацию</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default Promotion;
