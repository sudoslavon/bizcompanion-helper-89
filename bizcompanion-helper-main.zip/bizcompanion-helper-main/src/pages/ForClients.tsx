
import { useEffect } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useToast } from "@/components/ui/use-toast";
import { Form, FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { CheckCircle } from "lucide-react";

const formSchema = z.object({
  companyName: z.string().min(2, { message: "Введите название компании" }),
  fullName: z.string().min(2, { message: "Введите ФИО" }),
  phone: z.string().min(10, { message: "Введите корректный номер телефона" }),
  email: z.string().email({ message: "Введите корректный email" }),
  businessType: z.string().min(1, { message: "Укажите тип бизнеса" }),
  serviceType: z.string().min(1, { message: "Выберите тип услуги" }),
  description: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const ForClients = () => {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyName: "",
      fullName: "",
      phone: "",
      email: "",
      businessType: "",
      serviceType: "",
      description: "",
    },
  });
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  function onSubmit(data: FormValues) {
    console.log(data);
    toast({
      title: "Заявка отправлена",
      description: "Мы свяжемся с вами в ближайшее время",
    });
    form.reset();
  }

  const steps = [
    {
      title: "Оставьте заявку",
      description: "Заполните форму на сайте или свяжитесь с нами по телефону",
    },
    {
      title: "Получите консультацию",
      description: "Наш специалист свяжется с вами для обсуждения деталей и подбора оптимального решения",
    },
    {
      title: "Подпишите договор",
      description: "Заключите договор с нами и официальным исполнителем. Господдержка уже включена в стоимость",
    },
    {
      title: "Получите результат",
      description: "Исполнитель выполняет работу, а мы контролируем качество на каждом этапе",
    },
  ];

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <section className="bg-gradient-to-b from-blue-50 to-white py-12 md:py-24 relative">
          <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/f/f2/Coat_of_Arms_of_the_Russian_Federation.svg" 
              alt="Герб РФ" 
              className="h-[60%] w-auto object-contain"
            />
          </div>
          
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center mb-16">
              <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium mb-4">
                Для бизнеса и самозанятых
              </span>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Закажите продвижение с <span className="text-brand-blue">господдержкой</span>
              </h1>
              <p className="text-lg text-gray-600">
                Мы поможем вам найти лучших исполнителей и компенсируем до 50% затрат
                на digital-услуги по упаковке и продвижению вашего бизнеса
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-2xl font-bold mb-6 text-gray-900">Как мы работаем</h2>
                <div className="space-y-6">
                  {steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-brand-blue text-white flex items-center justify-center font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                        <p className="text-gray-600">{step.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 space-y-3">
                  <h3 className="font-semibold">Преимущества работы с нами:</h3>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-600">Компенсируем до 50% затрат на услуги по продвижению</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-600">Работаем только с аккредитованными исполнителями</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-600">Контролируем качество исполнения на каждом этапе</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="text-brand-green h-5 w-5 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-600">Компенсация сразу включена в стоимость услуг</p>
                  </div>
                </div>
              </div>
              
              <div className="glass-card p-6 md:p-8 rounded-xl shadow-sm">
                <h2 className="text-2xl font-bold mb-6 text-gray-900">Оставить заявку</h2>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Название компании / ИП / самозанятый</FormLabel>
                          <FormControl>
                            <Input placeholder="ООО 'Компания'" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ФИО контактного лица</FormLabel>
                          <FormControl>
                            <Input placeholder="Иванов Иван Иванович" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Телефон</FormLabel>
                            <FormControl>
                              <Input placeholder="+7 (___) ___-__-__" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="example@mail.ru" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="businessType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Тип бизнеса</FormLabel>
                          <FormControl>
                            <select 
                              className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                              {...field}
                            >
                              <option value="">Выберите тип бизнеса</option>
                              <option value="ООО">ООО</option>
                              <option value="ИП">ИП</option>
                              <option value="Самозанятый">Самозанятый</option>
                              <option value="Физлицо">Физическое лицо</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="serviceType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Интересующая услуга</FormLabel>
                          <FormControl>
                            <select 
                              className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                              {...field}
                            >
                              <option value="">Выберите услугу</option>
                              <option value="Упаковка">Упаковка бизнеса</option>
                              <option value="Продвижение">Продвижение</option>
                              <option value="AI">Внедрение искусственного интеллекта</option>
                              <option value="Планирование">Организационное планирование</option>
                              <option value="Консалтинг">Консалтинг по господдержке</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Дополнительная информация</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Опишите подробнее, что вам требуется" 
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-4">
                      <p className="text-xs text-gray-500">
                        Нажимая на кнопку, вы соглашаетесь на сбор и обработку персональных данных
                      </p>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-brand-blue hover:bg-brand-blue/90"
                      >
                        Отправить заявку
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default ForClients;
