
import { useEffect } from "react";
import HeroSection from "@/components/sections/HeroSection";
import ServiceBlocks from "@/components/sections/ServiceBlocks";
import TrustSection from "@/components/sections/TrustSection";
import AboutSection from "@/components/sections/AboutSection";
import ConsultingSection from "@/components/sections/ConsultingSection";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import PersonalDataForm from "@/components/forms/PersonalDataForm";
import ChatAssistant from "@/components/ui/ChatAssistant";

const Index = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Header />
      <main>
        <HeroSection />
        
        {/* Personal Data Form */}
        <PersonalDataForm />
        
        {/* Consulting Section - NEW */}
        <ConsultingSection />
        
        <ServiceBlocks />
        <TrustSection />
        <AboutSection />
        
        <section className="py-16 md:py-24 bg-brand-blue relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 bottom-0 bg-[url('https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?w=1920&auto=format&fit=crop&q=60')] opacity-10"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                Начните экономить на digital-продвижении уже сегодня
              </h2>
              <p className="text-blue-100 mb-8 text-lg">
                Получите до 50% компенсации затрат на современные решения для вашего бизнеса благодаря Господдержка.Бизнес
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button 
                  asChild
                  className="bg-white text-brand-blue hover:bg-white/90"
                >
                  <Link to="/for-clients">
                    Я заказчик
                  </Link>
                </Button>
                <Button 
                  asChild
                  variant="outline" 
                  className="border-white text-white hover:bg-white/10"
                >
                  <Link to="/for-contractors" className="flex items-center">
                    Я исполнитель
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Floating Chat Assistant */}
        <ChatAssistant />
      </main>
      <Footer />
    </>
  );
};

export default Index;
