
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Settings, CheckCircle, Percent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const OrgPlanning = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const services = [
    {
      title: "Разработка бизнес-планов",
      description: "Создание детальных бизнес-планов и оргструктур для эффективного управления персоналом",
      compensationPercent: 50
    },
    {
      title: "Составление рабочих регламентов",
      description: "Разработка регламентов и должностных инструкций для систематизации бизнес-процессов",
      compensationPercent: 45
    },
    {
      title: "Разработка шаблонов документов",
      description: "Создание шаблонов договоров, коммерческих предложений и других рабочих документов",
      compensationPercent: 40
    },
    {
      title: "Помощь в оформлении господдержки",
      description: "Профессиональное сопровождение в получении субсидий и других видов государственной поддержки",
      compensationPercent: 50
    },
    {
      title: "Стратегический консалтинг",
      description: "Консультации по стратегическому развитию бизнеса и оптимизации процессов",
      compensationPercent: 45
    },
    {
      title: "Формирование отделов продаж",
      description: "Разработка структуры отдела продаж, системы мотивации и KPI для сотрудников",
      compensationPercent: 40
    },
    {
      title: "Обучение по бизнес-процессам",
      description: "Проведение обучающих мероприятий для сотрудников по оптимизации рабочих процессов",
      compensationPercent: 35
    },
    {
      title: "Организация рабочего пространства",
      description: "Консультации по эффективной организации рабочего пространства и документооборота",
      compensationPercent: 30
    }
  ];

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <Button 
            asChild
            variant="ghost" 
            className="group mb-8"
          >
            <Link to="/" className="flex items-center">
              <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
              Назад на главную
            </Link>
          </Button>

          <div className="relative mb-12">
            <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/f/f2/Coat_of_Arms_of_the_Russian_Federation.svg" 
                alt="Герб РФ" 
                className="h-[300px] w-auto object-contain"
              />
            </div>
            
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="bg-brand-blue/10 p-6 rounded-xl">
                  <Settings className="h-16 w-16 text-brand-blue" />
                </div>
                
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                    Организационное планирование
                  </h1>
                  <p className="text-lg text-gray-700 mb-6 max-w-3xl">
                    Организационное планирование включает разработку бизнес-планов и оргструктур, 
                    составление рабочих регламентов, разработку шаблонов договоров и КП, 
                    помощь в оформлении господдержки, стратегический консалтинг, 
                    формирование отделов продаж и обучение по бизнес-процессам.
                  </p>
                  
                  <div className="bg-brand-blue/5 p-4 rounded-lg border border-brand-blue/10 mb-6">
                    <h3 className="font-semibold mb-2">Как получить поддержку:</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Заполните форму на нашем сайте</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Получите консультацию специалиста</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Заключите договор на услуги</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-brand-green mr-2 flex-shrink-0 mt-0.5" />
                        <span>Оформите заявку на компенсацию через портал Госуслуг</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Услуги с господдержкой в категории "Организационное планирование"
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center text-brand-green">
                    <Percent className="h-4 w-4 mr-1" />
                    <span>Компенсация до {service.compensationPercent}%</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between bg-brand-blue/5 p-8 rounded-xl">
            <div className="md:w-2/3 mb-6 md:mb-0">
              <h3 className="text-xl font-bold mb-2">Готовы оптимизировать ваш бизнес?</h3>
              <p className="text-gray-600">
                Получите консультацию специалиста и узнайте, как получить компенсацию до 50% затрат
              </p>
            </div>
            <div className="flex gap-4">
              <Button variant="outline">
                <Link to="/calculator">Рассчитать выгоду</Link>
              </Button>
              <Button className="bg-brand-blue hover:bg-brand-blue/90">
                <Link to="/chat">Получить консультацию</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default OrgPlanning;
