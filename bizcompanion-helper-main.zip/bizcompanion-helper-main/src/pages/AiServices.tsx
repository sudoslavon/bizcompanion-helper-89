
import { useState, useEffect } from "react";
import { 
  BrainCircuit, 
  Target, 
  Lightbulb, 
  LineChart,
  Search,
  Filter,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ServiceCard from "@/components/ui/ServiceCard";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

const AiServices = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);
  const [selectedMinPercent, setSelectedMinPercent] = useState<number | null>(null);
  const [isAnimating, setIsAnimating] = useState(true);
  
  const aiServices = [
    {
      id: "neuro-content",
      title: "Нейроконтент",
      description: "Автоматическая генерация постов, сторис и email-рассылок с помощью передовых нейросетей. Создавайте контент для соцсетей в 10 раз быстрее.",
      icon: <BrainCircuit className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 40,
      programName: "Цифровизация-2024",
      isPopular: true,
    },
    {
      id: "ai-targeting",
      title: "AI-таргетинг",
      description: "Умная настройка и оптимизация рекламы в социальных сетях с аналитикой в реальном времени. Увеличьте ROAS ваших рекламных кампаний.",
      icon: <Target className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 30,
      programName: "МСП Технологии",
      isPopular: false,
    },
    {
      id: "landing-pages",
      title: "Лендинги",
      description: "Создание высококонверсионных сайтов с AI-копирайтингом. Готовые шаблоны и быстрый запуск помогут привлечь новых клиентов.",
      icon: <Lightbulb className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 50,
      programName: "Инновации для бизнеса",
      isPopular: false,
    },
    {
      id: "analytics",
      title: "Бизнес-аналитика",
      description: "Автоматический анализ данных вашего бизнеса с помощью ИИ. Получайте инсайты и рекомендации для принятия важных решений.",
      icon: <LineChart className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 45,
      programName: "МСП Технологии",
      isPopular: false,
    },
    {
      id: "ai-chatbots",
      title: "AI-чатботы",
      description: "Разработка и внедрение интеллектуальных чат-ботов для автоматизации общения с клиентами на сайте и в мессенджерах.",
      icon: <BrainCircuit className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 45,
      programName: "Инновации для бизнеса",
      isPopular: true,
    },
    {
      id: "ai-agents",
      title: "Нейросетевые агенты",
      description: "Внедрение автономных AI-агентов, которые могут выполнять рутинные задачи и отвечать на вопросы клиентов 24/7.",
      icon: <Target className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 40,
      programName: "Цифровизация-2024",
      isPopular: false,
    },
    {
      id: "ai-data-analysis",
      title: "Анализ данных с ИИ",
      description: "Глубокий анализ бизнес-данных с помощью нейросетей для выявления трендов, прогнозирования и оптимизации бизнес-процессов.",
      icon: <LineChart className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 50,
      programName: "МСП Технологии",
      isPopular: false,
    },
    {
      id: "ai-training",
      title: "Обучение по нейросетям",
      description: "Курсы и персональные консультации по эффективному использованию ИИ для решения бизнес-задач.",
      icon: <Lightbulb className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 35,
      programName: "Инновации для бизнеса",
      isPopular: false,
    },
  ];

  const programs = [...new Set(aiServices.map(service => service.programName))];
  const percentages = [...new Set(aiServices.map(service => service.compensationPercent))].sort((a, b) => a - b);

  useEffect(() => {
    window.scrollTo(0, 0);
    
    const timer = setTimeout(() => {
      setIsAnimating(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  const filteredServices = aiServices.filter(service => {
    const matchesSearch = service.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          service.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesProgram = selectedProgram ? service.programName === selectedProgram : true;
    const matchesPercent = selectedMinPercent ? service.compensationPercent >= selectedMinPercent : true;
    
    return matchesSearch && matchesProgram && matchesPercent;
  });

  const handleClearFilters = () => {
    setSearchQuery("");
    setSelectedProgram(null);
    setSelectedMinPercent(null);
  };

  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className={`transition-all duration-500 ${isAnimating ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
            
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Услуги по внедрению искусственного интеллекта
              </h1>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Используйте современные технологии искусственного интеллекта для развития бизнеса и получайте компенсацию части затрат от государства
              </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4 mb-8">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Поиск услуг..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 py-6"
                />
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative">
                  <select
                    value={selectedProgram || ""}
                    onChange={(e) => setSelectedProgram(e.target.value || null)}
                    className="w-full h-10 pl-3 pr-10 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-brand-blue"
                  >
                    <option value="">Все программы</option>
                    {programs.map((program) => (
                      <option key={program} value={program}>
                        {program}
                      </option>
                    ))}
                  </select>
                  <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                </div>
                
                <div className="relative">
                  <select
                    value={selectedMinPercent || ""}
                    onChange={(e) => setSelectedMinPercent(e.target.value ? Number(e.target.value) : null)}
                    className="w-full h-10 pl-3 pr-10 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-brand-blue"
                  >
                    <option value="">Мин. % компенсации</option>
                    {percentages.map((percent) => (
                      <option key={percent} value={percent}>
                        От {percent}%
                      </option>
                    ))}
                  </select>
                  <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                </div>
                
                {(searchQuery || selectedProgram || selectedMinPercent) && (
                  <Button
                    variant="ghost"
                    onClick={handleClearFilters}
                    className="whitespace-nowrap"
                  >
                    Сбросить фильтры
                  </Button>
                )}
              </div>
            </div>

            {filteredServices.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
                {filteredServices.map((service) => (
                  <ServiceCard
                    key={service.id}
                    id={service.id}
                    title={service.title}
                    description={service.description}
                    icon={service.icon}
                    compensationPercent={service.compensationPercent}
                    programName={service.programName}
                    isPopular={service.isPopular}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">По вашему запросу ничего не найдено</p>
                <Button 
                  variant="outline" 
                  onClick={handleClearFilters}
                >
                  Сбросить фильтры
                </Button>
              </div>
            )}

            <div className="bg-brand-blue/5 rounded-xl p-6 md:p-8 mt-12">
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-3">
                    Не знаете, какую услугу выбрать?
                  </h2>
                  <p className="text-gray-600 mb-6 md:mb-0">
                    Получите бесплатную консультацию от наших специалистов и составьте персональный план цифровизации
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    asChild
                    variant="outline"
                  >
                    <a href="tel:+78001234567">
                      Позвонить нам
                    </a>
                  </Button>
                  <Button 
                    asChild
                    className="bg-brand-blue hover:bg-brand-blue/90"
                  >
                    <a href="/chat">
                      Получить консультацию
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default AiServices;
