
import { useState, useRef, useEffect } from "react";
import { 
  Send, 
  User, 
  Bot, 
  Phone, 
  Info, 
  ChevronUp, 
  ChevronDown,
  FileQuestion,
  Clock,
  Paperclip,
  X,
  Check,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

interface Message {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
}

const faqQuestions = [
  "Какие документы нужны для получения компенсации?",
  "Каков срок рассмотрения заявки на компенсацию?",
  "Могу ли я получить компенсацию, если мой бизнес работает менее года?",
  "Как быстро я получу деньги после одобрения заявки?",
  "Есть ли ограничения по сумме компенсации?",
];

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Добрый день! Я виртуальный ассистент компании Господдержка.Бизнес. Чем я могу вам помочь сегодня?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showFaqSection, setShowFaqSection] = useState(true);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    company: "",
    businessType: "",
    description: "",
  });
  const [showContactForm, setShowContactForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: newMessage,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage("");
    setIsTyping(true);

    // Simulate bot response delay
    setTimeout(() => {
      let botResponse = "";
      
      if (newMessage.toLowerCase().includes("документ")) {
        botResponse = "Для получения компенсации вам потребуются следующие документы: свидетельство ИНН, выписка из ЕГРЮЛ/ЕГРИП, договор на оказание услуг, акт выполненных работ, платежные документы. Наши специалисты помогут вам с подготовкой всех необходимых документов.";
      } else if (newMessage.toLowerCase().includes("срок")) {
        botResponse = "Средний срок рассмотрения заявки составляет 5-10 рабочих дней. После одобрения заявки деньги поступают на ваш расчетный счет в течение 7-14 дней.";
      } else if (newMessage.toLowerCase().includes("процент") || newMessage.toLowerCase().includes("компенсац")) {
        botResponse = "В зависимости от выбранной программы поддержки и вашего региона, вы можете получить компенсацию от 30% до 50% затрат на digital-услуги. Точный процент можно узнать, воспользовавшись нашим калькулятором.";
      } else if (newMessage.toLowerCase().includes("менеджер") || newMessage.toLowerCase().includes("специалист") || newMessage.toLowerCase().includes("консультация")) {
        botResponse = "Хотите поговорить с нашим специалистом? Я могу помочь вам оставить заявку на консультацию. Наш менеджер свяжется с вами в ближайшее время.";
        setShowContactForm(true);
      } else {
        botResponse = "Спасибо за ваш вопрос! Для получения более детальной информации, рекомендую оставить заявку на консультацию с нашим специалистом. Могу я помочь вам с этим?";
      }

      const botMessage: Message = {
        id: (Date.now() + 100).toString(),
        content: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleFaqClick = (question: string) => {
    setNewMessage(question);
    handleSendMessage();
  };

  const handleSubmitForm = () => {
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      
      const botMessage: Message = {
        id: Date.now().toString(),
        content: `Спасибо за ваше обращение, ${formData.name}! Ваша заявка успешно отправлена. Наш специалист свяжется с вами по номеру ${formData.phone} в ближайшее время для обсуждения деталей.`,
        sender: "bot",
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, botMessage]);
      setShowContactForm(false);
      setFormData({
        name: "",
        phone: "",
        company: "",
        businessType: "",
        description: "",
      });
    }, 2000);
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleFileClear = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <>
      <Header />
      <main className="pt-24 pb-16 min-h-screen bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Поддержка
              </h1>
              <p className="text-gray-600">
                Задайте вопрос нашему виртуальному ассистенту или оставьте заявку на консультацию
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
              <div className="bg-brand-blue px-6 py-4 flex items-center">
                <Bot className="text-white mr-2" />
                <div>
                  <h2 className="text-white font-medium">Умный ассистент</h2>
                  <div className="text-white/70 text-sm flex items-center">
                    <div className="w-2 h-2 rounded-full bg-green-400 mr-2"></div>
                    Онлайн
                  </div>
                </div>
              </div>
              
              <div className="p-4 md:p-6">
                <div 
                  className="mb-4 h-96 overflow-y-auto p-4 bg-gray-50 rounded-lg"
                  style={{ scrollBehavior: "smooth" }}
                >
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`mb-4 flex ${
                        message.sender === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-[80%] p-3 rounded-lg ${
                          message.sender === "user"
                            ? "bg-brand-blue text-white rounded-tr-none"
                            : "bg-white border border-gray-200 text-gray-700 rounded-tl-none"
                        }`}
                      >
                        <div className="flex items-center mb-1">
                          {message.sender === "user" ? (
                            <User className="h-4 w-4 mr-1" />
                          ) : (
                            <Bot className="h-4 w-4 mr-1" />
                          )}
                          <span className="text-xs">
                            {message.sender === "user" ? "Вы" : "Ассистент"}
                          </span>
                        </div>
                        <p className="text-sm">{message.content}</p>
                        <div
                          className={`text-xs mt-1 ${
                            message.sender === "user" ? "text-blue-100" : "text-gray-400"
                          }`}
                        >
                          {message.timestamp.toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </div>
                      </div>
                    </div>
                  ))}

                  {isTyping && (
                    <div className="flex justify-start mb-4">
                      <div className="bg-white border border-gray-200 p-3 rounded-lg rounded-tl-none max-w-[80%]">
                        <div className="flex items-center space-x-1">
                          <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse"></div>
                          <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse delay-100"></div>
                          <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse delay-200"></div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {showContactForm ? (
                  <div className="bg-gray-50 rounded-lg p-4 mb-4 animate-fade-in">
                    <h3 className="font-medium text-gray-900 mb-3">
                      Заявка на консультацию
                    </h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-gray-700 mb-1 block">
                            Ваше имя*
                          </label>
                          <Input
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Иван Иванов"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-700 mb-1 block">
                            Телефон*
                          </label>
                          <Input
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="+7 (999) 123-45-67"
                            required
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-gray-700 mb-1 block">
                            Название компании
                          </label>
                          <Input
                            name="company"
                            value={formData.company}
                            onChange={handleInputChange}
                            placeholder="ООО Компания"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-700 mb-1 block">
                            Форма бизнеса
                          </label>
                          <Input
                            name="businessType"
                            value={formData.businessType}
                            onChange={handleInputChange}
                            placeholder="ИП / ООО"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm text-gray-700 mb-1 block">
                          Опишите ваш запрос
                        </label>
                        <Textarea
                          name="description"
                          value={formData.description}
                          onChange={handleInputChange}
                          placeholder="Расскажите подробнее о вашем запросе..."
                          rows={3}
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-700 mb-1 block">
                          Прикрепить файл (необязательно)
                        </label>
                        <input
                          type="file"
                          ref={fileInputRef}
                          onChange={handleFileChange}
                          className="hidden"
                        />
                        {selectedFile ? (
                          <div className="flex items-center justify-between p-2 border rounded-md bg-gray-50">
                            <div className="flex items-center">
                              <Paperclip className="h-4 w-4 text-gray-500 mr-2" />
                              <span className="text-sm truncate max-w-xs">
                                {selectedFile.name}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={handleFileClear}
                              className="text-gray-500 hover:text-gray-700"
                            >
                              <X size={16} />
                            </button>
                          </div>
                        ) : (
                          <Button
                            type="button"
                            variant="outline"
                            className="w-full"
                            onClick={handleFileSelect}
                          >
                            <Paperclip className="h-4 w-4 mr-2" />
                            Прикрепить файл
                          </Button>
                        )}
                      </div>
                      <div className="flex justify-between">
                        <Button
                          variant="outline"
                          onClick={() => setShowContactForm(false)}
                        >
                          Отмена
                        </Button>
                        <Button
                          onClick={handleSubmitForm}
                          disabled={!formData.name || !formData.phone || isSubmitting}
                          className="bg-brand-blue hover:bg-brand-blue/90"
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Отправка...
                            </>
                          ) : (
                            <>
                              <Check className="mr-2 h-4 w-4" />
                              Отправить заявку
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex space-x-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Введите сообщение..."
                      className="flex-grow"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          handleSendMessage();
                        }
                      }}
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || isTyping}
                      className="bg-brand-blue hover:bg-brand-blue/90"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
              <div 
                className="px-6 py-4 flex justify-between items-center cursor-pointer"
                onClick={() => setShowFaqSection(!showFaqSection)}
              >
                <div className="flex items-center">
                  <FileQuestion className="text-brand-blue mr-2" />
                  <h2 className="font-medium text-gray-900">Часто задаваемые вопросы</h2>
                </div>
                {showFaqSection ? (
                  <ChevronUp className="h-5 w-5 text-gray-500" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-500" />
                )}
              </div>
              
              {showFaqSection && (
                <div className="p-6 border-t animate-fade-in">
                  <ul className="space-y-2">
                    {faqQuestions.map((question, index) => (
                      <li key={index}>
                        <button
                          className="text-left w-full py-2 px-3 rounded-lg hover:bg-gray-50 text-gray-700 flex items-center"
                          onClick={() => handleFaqClick(question)}
                        >
                          <Info className="h-4 w-4 text-brand-blue mr-2" />
                          <span>{question}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="px-6 py-4">
                <div className="flex items-center">
                  <Phone className="text-brand-blue mr-2" />
                  <h2 className="font-medium text-gray-900">Прямая связь</h2>
                </div>
              </div>
              <div className="p-6 border-t">
                <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">
                      Нужна срочная консультация?
                    </h3>
                    <p className="text-gray-600 text-sm">
                      Вы можете позвонить нам напрямую в рабочее время
                    </p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button variant="outline" className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      <span>9:00 - 18:00 (Пн-Пт)</span>
                    </Button>
                    <Button 
                      className="bg-brand-blue hover:bg-brand-blue/90 flex items-center"
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      <span>+7 (999) 123-45-67</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default Chat;
