
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";

const formSchema = z.object({
  fullName: z.string().min(3, { message: "ФИО должно содержать не менее 3 символов" }),
  email: z.string().email({ message: "Введите корректный email" }),
  phone: z.string().min(10, { message: "Введите корректный номер телефона" }),
  companyName: z.string().optional(),
  businessType: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const PersonalDataForm = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      companyName: "",
      businessType: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    console.log("Form data:", data);
    toast.success("Данные успешно отправлены!");
    setIsSubmitted(true);
  };

  return (
    <section className="py-8 md:py-12 bg-gradient-to-b from-brand-blue/5 to-white">
      <div className="container mx-auto px-4">
        <Card className="border-brand-blue/10 shadow-md">
          <CardHeader className="border-b pb-4">
            <div className="flex justify-between items-center cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
              <div>
                <CardTitle className="text-xl md:text-2xl text-brand-blue">
                  {isSubmitted ? "Спасибо за предоставленные данные!" : "Заполните персональные данные для получения господдержки"}
                </CardTitle>
                <CardDescription className="mt-1">
                  {isSubmitted 
                    ? "Мы свяжемся с вами в ближайшее время" 
                    : "Это поможет нам подобрать для вас оптимальные программы поддержки"}
                </CardDescription>
              </div>
              <Button variant="ghost" size="icon">
                {isExpanded ? <ChevronUp /> : <ChevronDown />}
              </Button>
            </div>
          </CardHeader>
          
          {isExpanded && !isSubmitted && (
            <CardContent className="pt-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ФИО</FormLabel>
                          <FormControl>
                            <Input placeholder="Иванов Иван Иванович" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Телефон</FormLabel>
                          <FormControl>
                            <Input placeholder="+7 (999) 123-45-67" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="businessType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Тип бизнеса</FormLabel>
                          <FormControl>
                            <select
                              className="w-full p-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue"
                              {...field}
                            >
                              <option value="">Выберите тип бизнеса</option>
                              <option value="individual">Самозанятый</option>
                              <option value="ip">ИП</option>
                              <option value="ooo">ООО</option>
                              <option value="other">Другое</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Название компании (если есть)</FormLabel>
                          <FormControl>
                            <Input placeholder="ООО «Компания»" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button type="submit" className="w-full md:w-auto">Отправить</Button>
                </form>
              </Form>
            </CardContent>
          )}
          
          {isExpanded && isSubmitted && (
            <CardContent className="pt-6">
              <div className="flex items-center text-brand-green gap-2">
                <CheckCircle className="h-5 w-5" />
                <span>Ваши данные успешно отправлены. Ожидайте звонка нашего специалиста.</span>
              </div>
            </CardContent>
          )}
        </Card>
      </div>
    </section>
  );
};

export default PersonalDataForm;
