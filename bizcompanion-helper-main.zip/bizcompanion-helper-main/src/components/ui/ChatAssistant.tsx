
import { useState, useEffect } from "react";
import { MessageCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const ChatAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<{text: string; isUser: boolean}[]>([
    {text: "Здравствуйте! Я ваш личный консультант по программам господдержки для бизнеса. Чем я могу вам помочь?", isUser: false}
  ]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // Add user message
    setMessages(prev => [...prev, {text: message, isUser: true}]);
    setMessage("");
    
    // Simulate assistant response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        text: "Спасибо за ваш вопрос! Господдержка.Бизнес помогает предпринимателям получать качественные услуги с государственной поддержкой. Мы свяжем вас со специалистом в ближайшее время. Есть ли у вас другие вопросы?",
        isUser: false
      }]);
    }, 1000);
  };

  // Handle submission with Enter key
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-50">
        {!isOpen ? (
          <Button 
            onClick={() => setIsOpen(true)} 
            size="lg" 
            className="rounded-full shadow-lg h-14 w-14 p-0 bg-brand-blue hover:bg-brand-blue/90"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
        ) : (
          <Card className="w-[320px] md:w-[350px] shadow-xl border-brand-blue/20">
            <CardHeader className="pb-2 flex flex-row items-center justify-between bg-brand-blue text-white rounded-t-lg">
              <CardTitle className="text-white text-lg">Консультант</CardTitle>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/20"
              >
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[300px] overflow-y-auto p-4 space-y-4">
                {messages.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[80%] rounded-lg p-3 ${
                        msg.isUser 
                          ? 'bg-brand-blue text-white rounded-tr-none' 
                          : 'bg-gray-100 text-gray-800 rounded-tl-none'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="p-3 border-t">
              <div className="flex w-full gap-2">
                <Input 
                  placeholder="Введите сообщение..." 
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="flex-1"
                />
                <Button 
                  size="sm" 
                  onClick={handleSendMessage}
                  className="bg-brand-blue hover:bg-brand-blue/90"
                >
                  Отправить
                </Button>
              </div>
            </CardFooter>
          </Card>
        )}
      </div>
    </>
  );
};

export default ChatAssistant;
