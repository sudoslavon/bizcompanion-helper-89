
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Calculator as CalcIcon, 
  Percent, 
  DollarSign,
  CheckCircle2
} from "lucide-react";

const Calculator = () => {
  const [budget, setBudget] = useState(100000);
  const [compensation, setCompensation] = useState(0);
  const [percentage, setPercentage] = useState(0);
  const [isCalculated, setIsCalculated] = useState(false);
  const [program, setProgram] = useState("");

  useEffect(() => {
    if (isCalculated) {
      // Calculate compensation based on budget
      let calculatedPercentage = 0;
      let programName = "";

      if (budget < 50000) {
        calculatedPercentage = 30;
        programName = "Цифровизация-2024";
      } else if (budget < 150000) {
        calculatedPercentage = 40;
        programName = "МСП Технологии";
      } else {
        calculatedPercentage = 50;
        programName = "Инновации для бизнеса";
      }

      const calculatedCompensation = budget * (calculatedPercentage / 100);
      
      // Smooth animation for the results
      const animationDuration = 1500;
      const startTime = Date.now();
      
      const animate = () => {
        const currentTime = Date.now();
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / animationDuration, 1);
        
        setPercentage(Math.round(progress * calculatedPercentage));
        setCompensation(Math.round(progress * calculatedCompensation));
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setProgram(programName);
        }
      };
      
      animate();
    }
  }, [budget, isCalculated]);

  const handleCalculate = () => {
    setIsCalculated(true);
  };

  const handleReset = () => {
    setBudget(100000);
    setCompensation(0);
    setPercentage(0);
    setIsCalculated(false);
    setProgram("");
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("ru-RU", {
      style: "currency",
      currency: "RUB",
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="glass-card rounded-xl p-6 md:p-8 transition-all duration-300">
      <div className="flex items-center mb-6">
        <div className="p-3 bg-brand-blue/10 rounded-lg mr-4">
          <CalcIcon className="text-brand-blue h-6 w-6" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900">
          Калькулятор компенсации
        </h3>
      </div>

      <div className="space-y-6">
        <div>
          <label className="flex justify-between text-sm font-medium text-gray-700 mb-2">
            <span>Ваш бюджет на digital-продвижение</span>
            <span className="font-semibold text-brand-blue">
              {formatCurrency(budget)}
            </span>
          </label>
          <Slider
            value={[budget]}
            min={10000}
            max={500000}
            step={10000}
            onValueChange={(value) => {
              setBudget(value[0]);
              setIsCalculated(false);
            }}
            className="mb-6"
          />
          <div className="flex justify-between text-xs text-gray-500">
            <span>10 000 ₽</span>
            <span>500 000 ₽</span>
          </div>
        </div>

        {!isCalculated ? (
          <Button 
            onClick={handleCalculate}
            className="w-full bg-brand-blue hover:bg-brand-blue/90"
          >
            Рассчитать мою компенсацию
          </Button>
        ) : (
          <div className="space-y-8 animate-fade-in">
            <div className="pt-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-gray-600">Процент возврата</span>
                <div className="flex items-center">
                  <Percent className="h-4 w-4 text-brand-green mr-1" />
                  <span className="text-xl font-bold text-brand-green">
                    {percentage}%
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-gray-600">Сумма компенсации</span>
                <div className="flex items-center">
                  <DollarSign className="h-4 w-4 text-brand-green mr-1" />
                  <span className="text-xl font-bold text-brand-green">
                    {formatCurrency(compensation)}
                  </span>
                </div>
              </div>

              {program && (
                <div className="flex items-center mt-6 p-3 bg-brand-green/10 rounded-lg animate-fade-in">
                  <CheckCircle2 className="h-5 w-5 text-brand-green mr-2" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      Программа поддержки
                    </p>
                    <p className="text-sm text-gray-600">{program}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-2 flex gap-4">
              <Button 
                variant="outline" 
                onClick={handleReset}
                className="w-1/2"
              >
                Сбросить
              </Button>
              <Button 
                className="w-1/2 bg-brand-blue hover:bg-brand-blue/90"
              >
                Оформить заявку
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Calculator;
