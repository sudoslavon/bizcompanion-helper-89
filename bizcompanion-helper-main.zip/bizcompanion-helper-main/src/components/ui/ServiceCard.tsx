
import { useState } from "react";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, Percent, FileText } from "lucide-react";

interface ServiceCardProps {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  compensationPercent: number;
  programName: string;
  isPopular?: boolean;
  marketPrice?: string;
}

const ServiceCard = ({
  id,
  title,
  description,
  icon,
  compensationPercent,
  programName,
  isPopular = false,
  marketPrice,
}: ServiceCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`glass-card rounded-xl overflow-hidden transition-all duration-300 h-full flex flex-col ${
        isHovered ? "shadow-md translate-y-[-4px]" : "shadow-sm"
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isPopular && (
        <div className="bg-brand-blue py-1.5 px-4 text-center">
          <span className="text-white text-xs font-medium">
            Популярная услуга
          </span>
        </div>
      )}

      <div className="p-6 flex flex-col flex-grow">
        <div className="mb-4">{icon}</div>
        
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
        
        <p className="text-gray-600 mb-4 text-sm min-h-[60px]">
          {description}
        </p>
        
        <div className="mt-auto">
          <div className="flex items-center mb-3">
            <Badge 
              variant="outline" 
              className="font-normal border-brand-green/30 text-brand-green flex items-center gap-1.5"
            >
              <Percent className="h-3.5 w-3.5" />
              <span>Компенсация {compensationPercent}%</span>
            </Badge>
          </div>
          
          {marketPrice && (
            <div className="text-sm text-gray-500 mb-3">
              <span className="line-through">{marketPrice}</span> (рыночная стоимость)
            </div>
          )}
          
          <div className="mb-4">
            <span className="text-xs text-gray-500 block">
              Программа "{programName}"
            </span>
            <div className="flex items-center mt-1 text-xs text-gray-500">
              <FileText className="h-3.5 w-3.5 mr-1.5 text-brand-green" />
              <span>Доступен налоговый вычет для юр. лиц</span>
            </div>
          </div>
          
          <div className="flex">
            <Button 
              asChild
              className="w-full bg-brand-blue hover:bg-brand-blue/90 whitespace-nowrap"
            >
              <Link to={`/services/${id}`} className="flex items-center justify-center">
                <span>Подробнее</span>
                <ArrowRight 
                  className={`ml-2 h-4 w-4 transition-transform duration-300 ${
                    isHovered ? "translate-x-1" : ""
                  }`} 
                />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
