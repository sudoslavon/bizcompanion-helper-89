
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Menu, X, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setIsScrolled(offset > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "py-3 bg-white/80 backdrop-blur-lg shadow-sm"
          : "py-5 bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link 
          to="/" 
          className="flex items-center gap-2 font-bold text-brand-blue text-xl tracking-tight"
        >
          Господдержка.Бизнес
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/services" className="link-underline font-medium">
            Услуги
          </Link>
          <Link to="/about" className="link-underline font-medium">
            О нас
          </Link>
          <Link to="/faq" className="link-underline font-medium">
            Вопросы и ответы
          </Link>
          <Button asChild variant="ghost" className="text-brand-blue">
            <Link to="/chat">
              <MessageCircle size={18} className="mr-2" />
              Поддержка
            </Link>
          </Button>
          <Button asChild className="bg-brand-blue hover:bg-brand-blue/90">
            <Link to="/calculator">Рассчитать компенсацию</Link>
          </Button>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-brand-blue"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-md animate-slide-down">
          <div className="container mx-auto py-4 px-4 flex flex-col space-y-4">
            <Link
              to="/services"
              className="py-2 px-4 hover:bg-gray-100 rounded-md font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Услуги
            </Link>
            <Link
              to="/about"
              className="py-2 px-4 hover:bg-gray-100 rounded-md font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              О нас
            </Link>
            <Link
              to="/faq"
              className="py-2 px-4 hover:bg-gray-100 rounded-md font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Вопросы и ответы
            </Link>
            <Link
              to="/chat"
              className="py-2 px-4 hover:bg-gray-100 rounded-md font-medium flex items-center"
              onClick={() => setIsMenuOpen(false)}
            >
              <MessageCircle size={18} className="mr-2" />
              Поддержка
            </Link>
            <Button 
              asChild 
              className="bg-brand-blue hover:bg-brand-blue/90 w-full"
              onClick={() => setIsMenuOpen(false)}
            >
              <Link to="/calculator">Рассчитать компенсацию</Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
