import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MessageCircle, Search } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="font-bold text-lg text-gray-900">Господдержка.Бизнес</h3>
            <p className="text-gray-600 text-sm">
              Оператор между исполнителями и заказчиками, помогающий бизнесу 
              развиваться с господдержкой. Работаем при поддержке корпорации МСП 
              и Минэкономразвития РФ.
            </p>
            <div className="flex space-x-3">
              <a 
                href="https://t.me/yourtelegram" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-brand-blue transition-colors"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
              <a 
                href="https://vk.com/yourvk" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-brand-blue transition-colors"
              >
                <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                  <path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93V15.07C2 20.67 3.33 22 8.93 22H15.07C20.67 22 22 20.67 22 15.07V8.93C22 3.33 20.67 2 15.07 2ZM18.15 16.27H16.69C16.14 16.27 15.97 15.82 14.86 14.72C13.86 13.77 13.49 13.67 13.27 13.67C12.93 13.67 12.83 13.76 12.83 14.25V15.68C12.83 16.04 12.71 16.27 11.72 16.27C10.12 16.27 8.36 15.35 7.06 13.7C5.1 11.19 4.5 9.17 4.5 8.77C4.5 8.55 4.6 8.36 5 8.36H6.47C6.84 8.36 6.98 8.53 7.13 8.97C7.78 10.89 8.94 12.54 9.44 12.54C9.66 12.54 9.75 12.44 9.75 11.91V10.07C9.7 9.13 9.19 9.06 9.19 8.71C9.19 8.55 9.32 8.36 9.54 8.36H11.89C12.19 8.36 12.29 8.55 12.29 8.94V11.5C12.29 11.8 12.42 11.91 12.5 11.91C12.73 11.91 12.91 11.8 13.33 11.4C14.29 10.33 15 8.72 15 8.72C15.1 8.5 15.27 8.36 15.64 8.36H17.11C17.56 8.36 17.68 8.61 17.56 8.97C17.36 9.76 15.96 11.77 15.96 11.77C15.79 12.04 15.73 12.15 15.96 12.44C16.12 12.67 16.62 13.11 16.96 13.5C17.6 14.25 18.1 14.91 18.27 15.32C18.34 15.82 18.1 16.27 18.15 16.27Z" />
                </svg>
              </a>
              <a 
                href="https://ya.ru" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-brand-blue transition-colors"
              >
                <Search className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-4">Услуги</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/packaging" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Упаковка бизнеса
                </Link>
              </li>
              <li>
                <Link to="/promotion" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Продвижение
                </Link>
              </li>
              <li>
                <Link to="/ai-implementation" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Внедрение ИИ
                </Link>
              </li>
              <li>
                <Link to="/org-planning" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Организационное планирование
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Все услуги
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-4">Информация</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/for-clients" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Для заказчиков
                </Link>
              </li>
              <li>
                <Link to="/for-contractors" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Для исполнителей
                </Link>
              </li>
              <li>
                <Link to="/calculator" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Калькулятор выгоды
                </Link>
              </li>
              <li>
                <Link to="/chat" className="text-gray-600 hover:text-brand-blue transition-colors">
                  Консультация
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-4">Контакты</h3>
            <div className="space-y-2">
              <p className="text-gray-600">Москва, ул. Цифровая, 128</p>
              <p className="text-gray-600">
                <a href="tel:+74951234567" className="hover:text-brand-blue transition-colors">
                  +7 (495) 123-45-67
                </a>
              </p>
              <p className="text-gray-600">
                <a href="mailto:info@digitalsupport.ru" className="hover:text-brand-blue transition-colors">
                  info@gospodderzhka.biz
                </a>
              </p>
              <Button 
                asChild
                className="mt-2 bg-brand-blue hover:bg-brand-blue/90"
              >
                <Link to="/chat">
                  Связаться с нами
                </Link>
              </Button>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-6 border-t border-gray-200">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} Господдержка.Бизнес. Все права защищены.
            </p>
            <div className="flex gap-4 text-sm text-gray-500">
              <Link to="/privacy" className="hover:text-brand-blue transition-colors">
                Политика конфиденциальности
              </Link>
              <Link to="/terms" className="hover:text-brand-blue transition-colors">
                Условия использования
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      {/* RF Emblem background */}
      <div className="py-3 bg-gray-100 border-t border-gray-200 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/f/f2/Coat_of_Arms_of_the_Russian_Federation.svg" 
            alt="Герб РФ" 
            className="h-full w-auto object-contain"
          />
        </div>
        <div className="container mx-auto px-4">
          <p className="text-xs text-center text-gray-600">
            При поддержке корпорации МСП и Министерства экономического развития Российской Федерации
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
