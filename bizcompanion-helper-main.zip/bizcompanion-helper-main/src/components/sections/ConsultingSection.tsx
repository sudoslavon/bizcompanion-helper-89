
import React from "react";
import { CircleDollarSign, Users, Clock, FileCheck, BarChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ConsultingSection = () => {
  const supportPrograms = [
    {
      name: "Программа цифровизации МСП",
      description: "Компенсация до 50% затрат на IT-решения",
      recipients: "12,500+ компаний",
      timeframe: "30-60 дней"
    },
    {
      name: "Гранты на инновации",
      description: "Финансирование технологических стартапов",
      recipients: "850+ проектов",
      timeframe: "60-90 дней"
    },
    {
      name: "Субсидии на модернизацию",
      description: "Возмещение части затрат на оборудование",
      recipients: "3,200+ предприятий",
      timeframe: "45-75 дней"
    },
    {
      name: "Льготное кредитование",
      description: "Кредиты по ставке от 3% для МСП",
      recipients: "5,700+ организаций",
      timeframe: "14-30 дней"
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-white via-blue-50/30 to-white relative">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Комплексная помощь в получении господдержки
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Профессиональное сопровождение от консультации до получения средств
            </p>
          </div>

          <div className="glass-card p-6 md:p-8 rounded-xl mb-12">
            <div className="flex flex-col md:flex-row gap-6 md:gap-10 items-start md:items-center mb-6">
              <div className="flex-shrink-0 bg-brand-blue/10 p-4 rounded-full">
                <CircleDollarSign className="h-10 w-10 text-brand-blue" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Помощь в получении господдержки для бизнеса</h3>
                <p className="text-gray-600">
                  Консалтинг, сбор документов, подача заявок, разработка бизнес-планов. Стоимость рассчитывается индивидуально под каждый проект, в среднем ~10% от суммы оказанной поддержки, которая будет заложена в смету заявки.
                </p>
              </div>
            </div>

            <div className="flex justify-center mt-6">
              <Button 
                asChild
                className="bg-brand-blue hover:bg-brand-blue/90 px-6"
              >
                <Link to="/calculator">
                  Рассчитать стоимость услуг
                </Link>
              </Button>
            </div>
          </div>

          <div className="mb-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Популярные программы поддержки</h3>
              <span className="text-sm font-medium text-brand-blue">Бюджет на 2025 год: 2,7 трлн ₽</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {supportPrograms.map((program, index) => (
                <div key={index} className="glass-card p-4 md:p-5 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-1">{program.name}</h4>
                  <p className="text-sm text-gray-600 mb-3">{program.description}</p>
                  <div className="flex justify-between text-xs text-gray-500">
                    <div className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5" />
                      <span>{program.recipients}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      <span>{program.timeframe}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            <div className="glass-card p-6 rounded-lg">
              <div className="flex justify-center mb-4">
                <FileCheck className="h-10 w-10 text-brand-blue" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-1">22,450+</h4>
              <p className="text-sm text-gray-600">Предприятий получили поддержку в 2024 году</p>
            </div>
            <div className="glass-card p-6 rounded-lg">
              <div className="flex justify-center mb-4">
                <BarChart className="h-10 w-10 text-brand-green" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-1">1.8 трлн ₽</h4>
              <p className="text-sm text-gray-600">Выделено на программы поддержки в 2024 году</p>
            </div>
            <div className="glass-card p-6 rounded-lg">
              <div className="flex justify-center mb-4">
                <Clock className="h-10 w-10 text-brand-blue" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-1">45 дней</h4>
              <p className="text-sm text-gray-600">Средний срок получения поддержки</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ConsultingSection;
