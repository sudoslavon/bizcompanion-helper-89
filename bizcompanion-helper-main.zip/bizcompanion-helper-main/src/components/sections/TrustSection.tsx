
import { useState, useEffect, useRef } from "react";
import { 
  ChevronLeft, 
  ChevronRight, 
  Star, 
  Award, 
  ShieldCheck,
  FileCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface Testimonial {
  id: number;
  name: string;
  company: string;
  image: string;
  role: string;
  content: string;
  saved: string;
}

const TrustSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const slideRef = useRef<HTMLDivElement>(null);

  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Алексей Петров",
      company: "ИП Петров А.И.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&auto=format&fit=crop&q=80",
      role: "Владелец бизнеса",
      content: "Благодаря программе компенсации смог позволить себе полноценный ребрендинг компании и запуск таргетированной рекламы. Сервис помог оформить все документы и уже через 2 недели я получил возмещение 50% затрат!",
      saved: "60 000 ₽",
    },
    {
      id: 2,
      name: "Елена Смирнова",
      company: "Цветочный салон «Флора»",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&auto=format&fit=crop&q=80",
      role: "Директор",
      content: "Никогда не думала, что получение государственной поддержки может быть таким простым. Оформила компенсацию на нейроконтент и аналитику. Отличный сервис, рекомендую всем предпринимателям!",
      saved: "45 000 ₽",
    },
    {
      id: 3,
      name: "Михаил Иванов",
      company: "ООО «ТехноПлюс»",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&auto=format&fit=crop&q=80",
      role: "Коммерческий директор",
      content: "Сервис помог нам получить компенсацию за создание лендинга и настройку AI-таргетинга. Всё оформили быстро, без бюрократии. Планируем и дальше использовать эту платформу для развития бизнеса.",
      saved: "83 000 ₽",
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      goToNext();
    }, 5000);
    return () => clearInterval(interval);
  }, [currentIndex]);

  const goToPrev = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
    setTimeout(() => setIsAnimating(false), 500);
  };

  const goToNext = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
    setTimeout(() => setIsAnimating(false), 500);
  };

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium mb-4">
            Нам доверяют
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Истории успеха клиентов
          </h2>
          <p className="text-gray-600">
            Более 500 предпринимателей уже получили компенсацию от государства с нашей помощью
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="w-full lg:w-1/2">
            <div className="relative">
              <div className="glass-card rounded-xl p-6 md:p-8 mb-4">
                <div className="flex flex-wrap items-center justify-between mb-6">
                  <div className="flex items-center">
                    <div className="flex items-center gap-0.5 mr-3">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-brand-blue text-brand-blue" />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">5.0</span>
                  </div>
                  <div className="flex items-center">
                    <Award className="w-5 h-5 text-brand-green mr-2" />
                    <span className="text-sm font-medium text-brand-green">
                      Экономия: {testimonials[currentIndex].saved}
                    </span>
                  </div>
                </div>

                <div 
                  ref={slideRef}
                  className="mb-6 relative overflow-hidden" 
                  style={{ minHeight: '200px' }}
                >
                  <div 
                    className={`transition-opacity duration-500 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}
                  >
                    <p className="text-gray-700 text-lg mb-8">
                      "{testimonials[currentIndex].content}"
                    </p>
                    <div className="flex items-center">
                      <img 
                        src={testimonials[currentIndex].image} 
                        alt={testimonials[currentIndex].name}
                        className="w-16 h-16 rounded-full object-cover mr-4"
                      />
                      <div>
                        <h4 className="font-semibold text-gray-900">
                          {testimonials[currentIndex].name}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {testimonials[currentIndex].role}, {testimonials[currentIndex].company}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    {testimonials.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          if (isAnimating) return;
                          setIsAnimating(true);
                          setCurrentIndex(index);
                          setTimeout(() => setIsAnimating(false), 500);
                        }}
                        className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                          index === currentIndex 
                            ? "bg-brand-blue scale-125" 
                            : "bg-gray-300 hover:bg-gray-400"
                        }`}
                        aria-label={`Go to testimonial ${index + 1}`}
                      />
                    ))}
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={goToPrev}
                      className="h-8 w-8 rounded-full"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={goToNext}
                      className="h-8 w-8 rounded-full"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Почему нам доверяют
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-card p-6 rounded-xl">
                  <ShieldCheck className="w-10 h-10 text-brand-blue mb-4" />
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">
                    Официальный партнер МСП
                  </h4>
                  <p className="text-gray-600 text-sm">
                    Мы являемся аккредитованным партнером Корпорации МСП и имеем все необходимые сертификаты.
                  </p>
                </div>
                
                <div className="glass-card p-6 rounded-xl">
                  <FileCheck className="w-10 h-10 text-brand-blue mb-4" />
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">
                    Юридическая поддержка
                  </h4>
                  <p className="text-gray-600 text-sm">
                    Наши юристы помогут оформить все документы и проконсультируют по всем вопросам.
                  </p>
                </div>
                
                <div className="glass-card p-6 rounded-xl col-span-1 md:col-span-2">
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <img 
                      src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=400&h=300&auto=format&fit=crop&q=80" 
                      alt="Сертификат" 
                      className="w-full md:w-40 h-32 object-cover rounded-lg"
                    />
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">
                        Сертификат соответствия №МСП-2023/114
                      </h4>
                      <p className="text-gray-600 text-sm mb-4">
                        Наша компания прошла проверку и получила сертификат соответствия требованиям программ государственной поддержки малого и среднего предпринимательства.
                      </p>
                      <Button variant="outline" size="sm">
                        Проверить подлинность
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
