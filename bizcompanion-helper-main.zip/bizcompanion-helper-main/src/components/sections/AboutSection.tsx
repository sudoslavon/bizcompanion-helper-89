
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Shield,
  CheckCircle,
  Users,
  BarChart4,
  Calendar,
  Wallet,
} from "lucide-react";

const AboutSection = () => {
  const [activeTab, setActiveTab] = useState<"about" | "process">("about");

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium mb-4">
            О нас
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Господдержка.Бизнес
          </h2>
          <p className="text-gray-600">
            Мы помогаем малому и среднему бизнесу получать компенсацию затрат на digital-услуги через государственные программы поддержки
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-16 items-start">
          <div className="w-full md:w-2/5">
            <div className="sticky top-24">
              <div className="mb-8 inline-flex p-1 border rounded-lg bg-gray-50">
                <button
                  className={`py-2 px-4 text-sm font-medium rounded-md transition-all ${
                    activeTab === "about"
                      ? "bg-white shadow-sm text-gray-900"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                  onClick={() => setActiveTab("about")}
                >
                  О компании
                </button>
                <button
                  className={`py-2 px-4 text-sm font-medium rounded-md transition-all ${
                    activeTab === "process"
                      ? "bg-white shadow-sm text-gray-900"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                  onClick={() => setActiveTab("process")}
                >
                  Как это работает
                </button>
              </div>

              <div
                className={`transition-all duration-300 ${
                  activeTab === "about" ? "block" : "hidden"
                }`}
              >
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  Мы делаем господдержку доступной
                </h3>
                <p className="text-gray-600 mb-6">
                  Наша миссия — помочь малому и среднему бизнесу использовать современные цифровые инструменты и технологии, получая при этом компенсацию части затрат от государства.
                </p>

                <div className="space-y-5 mb-8">
                  <div className="flex gap-3">
                    <div className="flex-shrink-0 h-7 w-7 rounded-full bg-brand-blue/10 flex items-center justify-center">
                      <CheckCircle className="h-4 w-4 text-brand-blue" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">
                        Официальный партнер
                      </h4>
                      <p className="text-sm text-gray-600">
                        Аккредитованный партнер Корпорации МСП и Минэкономразвития
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="flex-shrink-0 h-7 w-7 rounded-full bg-brand-blue/10 flex items-center justify-center">
                      <Users className="h-4 w-4 text-brand-blue" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">
                        Команда экспертов
                      </h4>
                      <p className="text-sm text-gray-600">
                        Опытные специалисты в области господдержки и digital-маркетинга
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="flex-shrink-0 h-7 w-7 rounded-full bg-brand-blue/10 flex items-center justify-center">
                      <BarChart4 className="h-4 w-4 text-brand-blue" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">
                        Проверенные результаты
                      </h4>
                      <p className="text-sm text-gray-600">
                        Более 500 компаний уже получили компенсацию с нашей помощью
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mb-8 p-5 bg-brand-blue/5 rounded-lg border border-brand-blue/10">
                  <div className="flex items-start gap-3">
                    <Shield className="w-6 h-6 text-brand-blue flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-medium text-gray-900 mb-1">
                        Важно знать
                      </h4>
                      <p className="text-sm text-gray-600">
                        Мы не гарантируем одобрение компенсации — решение принимает МСП на основании представленных документов. Однако наш опыт позволяет максимально повысить шансы на получение поддержки.
                      </p>
                    </div>
                  </div>
                </div>

                <Button 
                  className="w-full bg-brand-blue hover:bg-brand-blue/90"
                >
                  Узнать подробнее
                </Button>
              </div>

              <div
                className={`transition-all duration-300 ${
                  activeTab === "process" ? "block" : "hidden"
                }`}
              >
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  Процесс получения компенсации
                </h3>
                <p className="text-gray-600 mb-8">
                  Получение компенсации от государства с нашей помощью — это простой и прозрачный процесс, состоящий из 4 основных шагов.
                </p>

                <div className="space-y-8 mb-8">
                  <div className="flex gap-5">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-brand-blue text-white flex items-center justify-center font-semibold">
                      1
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Calendar className="h-4 w-4 text-brand-blue" />
                        <h4 className="font-medium text-gray-900">
                          Подача заявки
                        </h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        Заполните заявку на нашем сайте или в приложении, выбрав интересующие вас digital-услуги.
                      </p>
                      <div className="text-xs text-gray-500">
                        Срок: 15 минут
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-5">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-brand-blue text-white flex items-center justify-center font-semibold">
                      2
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Users className="h-4 w-4 text-brand-blue" />
                        <h4 className="font-medium text-gray-900">
                          Консультация
                        </h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        Наш менеджер свяжется с вами, подберет оптимальную программу поддержки и поможет подготовить документы.
                      </p>
                      <div className="text-xs text-gray-500">
                        Срок: 1-2 дня
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-5">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-brand-blue text-white flex items-center justify-center font-semibold">
                      3
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <CheckCircle className="h-4 w-4 text-brand-blue" />
                        <h4 className="font-medium text-gray-900">
                          Оказание услуг
                        </h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        Мы оказываем выбранные вами услуги, предоставляем отчеты и помогаем оформить все необходимые документы для МСП.
                      </p>
                      <div className="text-xs text-gray-500">
                        Срок: 5-14 дней
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-5">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-brand-blue text-white flex items-center justify-center font-semibold">
                      4
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Wallet className="h-4 w-4 text-brand-blue" />
                        <h4 className="font-medium text-gray-900">
                          Получение компенсации
                        </h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        После одобрения заявки МСП перечисляет компенсацию на ваш расчетный счет.
                      </p>
                      <div className="text-xs text-gray-500">
                        Срок: 7-14 дней
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  className="w-full bg-brand-blue hover:bg-brand-blue/90"
                >
                  Начать процесс
                </Button>
              </div>
            </div>
          </div>

          <div className="w-full md:w-3/5">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1521791136064-7986c2920216?w=800&auto=format&fit=crop&q=80"
                alt="Наша команда"
                className="w-full h-auto rounded-xl shadow-md"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-md">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-brand-blue">500+</div>
                    <div className="text-xs text-gray-600">Клиентов</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-brand-blue">30M+</div>
                    <div className="text-xs text-gray-600">Рублей возмещено</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-brand-blue">98%</div>
                    <div className="text-xs text-gray-600">Одобренных заявок</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-16 space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">
                Часто задаваемые вопросы
              </h3>
              
              <div className="glass-card p-6 rounded-xl">
                <h4 className="font-semibold text-gray-900 mb-2">
                  Кто может получить компенсацию?
                </h4>
                <p className="text-gray-600 text-sm">
                  Компенсацию могут получить субъекты малого и среднего предпринимательства (ИП и ООО), включенные в реестр МСП и соответствующие требованиям выбранной программы поддержки.
                </p>
              </div>
              
              <div className="glass-card p-6 rounded-xl">
                <h4 className="font-semibold text-gray-900 mb-2">
                  Какой процент затрат можно компенсировать?
                </h4>
                <p className="text-gray-600 text-sm">
                  В зависимости от программы поддержки и региона, можно получить компенсацию от 30% до 50% затрат на digital-услуги. Точный процент рассчитывается индивидуально.
                </p>
              </div>
              
              <div className="glass-card p-6 rounded-xl">
                <h4 className="font-semibold text-gray-900 mb-2">
                  Как быстро можно получить компенсацию?
                </h4>
                <p className="text-gray-600 text-sm">
                  Средний срок от подачи заявки до получения компенсации составляет 2-4 недели. Точный срок зависит от выбранной программы и скорости рассмотрения документов МСП.
                </p>
              </div>
              
              <div className="glass-card p-6 rounded-xl">
                <h4 className="font-semibold text-gray-900 mb-2">
                  Какие документы необходимы?
                </h4>
                <p className="text-gray-600 text-sm">
                  Основные документы: копия свидетельства ИНН, выписка из ЕГРЮЛ/ЕГРИП, договор на оказание услуг, акт выполненных работ, документы об оплате. Наши специалисты помогут вам подготовить полный пакет документов.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
