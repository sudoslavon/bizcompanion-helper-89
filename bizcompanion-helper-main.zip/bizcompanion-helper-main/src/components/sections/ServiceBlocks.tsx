
import { BrainCircuit, Package, Rocket, Settings } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ServiceBlocks = () => {
  const serviceBlocks = [
    {
      id: "packaging",
      title: "Упаковка",
      description: "Разработка сайтов, оформление социальных сетей, регистрация на онлайн-картах, заполнение карточек компаний в бизнес-справочниках и агрегаторах, брендирование, стратегия продвижения и многое другое.",
      icon: <Package className="h-10 w-10 text-brand-blue" />,
      link: "/packaging",
      startingPrice: "от 15 000 ₽",
      marketPrice: "30 000 ₽",
      compensation: "до 50%",
    },
    {
      id: "promotion",
      title: "Продвижение",
      description: "Настройка таргетированной и контекстной рекламы, помощь в закупке рекламы у пабликов и блогеров, разработка контент-плана, съёмка контента, помощь с полиграфией и другие маркетинговые услуги.",
      icon: <Rocket className="h-10 w-10 text-brand-blue" />,
      link: "/promotion",
      startingPrice: "от 20 000 ₽",
      marketPrice: "40 000 ₽",
      compensation: "до 40%",
    },
    {
      id: "ai-implementation",
      title: "Внедрение искусственного интеллекта",
      description: "Предоставление чат-ботов нейросетей и обучение по ним, внедрение нейросетевых агентов и сотрудников, анализ данных с помощь ИИ и автоматизация бизнес-процессов с применением современных технологий.",
      icon: <BrainCircuit className="h-10 w-10 text-brand-blue" />,
      link: "/ai-implementation",
      startingPrice: "от 25 000 ₽",
      marketPrice: "50 000 ₽",
      compensation: "до 45%",
    },
    {
      id: "org-planning",
      title: "Организационное планирование",
      description: "Разработка бизнес-планов и оргструктур для сотрудников, составление рабочих регламентов, разработка шаблонов договоров и КП, помощь в оформлении господдержки, стратегический консалтинг и формирование отделов продаж.",
      icon: <Settings className="h-10 w-10 text-brand-blue" />,
      link: "/org-planning",
      startingPrice: "от 30 000 ₽",
      marketPrice: "60 000 ₽",
      compensation: "до 35%",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium mb-4">
            Наши направления
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Господдержка по упаковке и продвижению бизнеса в интернете и социальных сетях
          </h2>
          <p className="text-gray-600">
            Мы являемся оператором между исполнителями и заказчиками, курируя процессы и компенсируя часть затрат через государственные программы поддержки
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {serviceBlocks.map((block) => (
            <Card key={block.id} className="hover:shadow-lg transition-shadow duration-300 border-t-4 border-t-brand-blue relative overflow-hidden h-full flex flex-col">
              <div className="absolute bottom-0 right-0 w-20 h-20 opacity-5">
                {block.icon}
              </div>
              <CardHeader className="pb-2">
                <div className="mb-4">{block.icon}</div>
                <CardTitle className="text-2xl">{block.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 flex-grow flex flex-col">
                <CardDescription className="text-gray-600 text-base flex-grow">
                  {block.description}
                </CardDescription>
                <div className="mt-auto">
                  <div className="flex justify-between items-center text-sm mb-1">
                    <div className="text-gray-700 font-medium">{block.startingPrice}</div>
                    <div className="text-brand-green">Компенсация {block.compensation}</div>
                  </div>
                  <div className="text-sm text-gray-500 mb-4">
                    <span className="line-through">{block.marketPrice}</span> (рыночная стоимость)
                  </div>
                  <p className="text-xs text-gray-500 mb-4">Цены варьируются в зависимости от оборотов компании. Доступен налоговый вычет для юр. лиц.</p>
                  <Button asChild variant="default" className="bg-brand-blue hover:bg-brand-blue/90 w-full">
                    <Link to={block.link}>Подробнее</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServiceBlocks;
