
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronRight, CheckCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";

const HeroSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [phone, setPhone] = useState("");
  const { toast } = useToast();
  
  const steps = [
    { title: "Упаковка бизнеса", description: "Подберите подходящие услуги для успешного старта" },
    { title: "Господдержка", description: "Получите компенсацию до 50% затрат на digital-услуги" },
    { title: "Продвижение", description: "Выведите бизнес на новый уровень с помощью экспертов" }
  ];

  useEffect(() => {
    setIsVisible(true);
    
    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev === steps.length - 1 ? 0 : prev + 1));
    }, 4000);
    
    return () => clearInterval(interval);
  }, [steps.length]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length < 10) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Пожалуйста, введите корректный номер телефона",
      });
      return;
    }
    
    toast({
      title: "Заявка принята!",
      description: "Мы свяжемся с вами в ближайшее время",
    });
    setPhone("");
  };

  return (
    <section className="relative pt-20 pb-16 md:pt-28 md:pb-20 overflow-hidden bg-gradient-to-br from-blue-50/60 via-blue-50/30 to-white/70">
      {/* Decorative elements */}
      <div className="absolute top-20 right-10 w-64 h-64 bg-brand-blue/5 rounded-full blur-2xl -z-10"></div>
      <div className="absolute bottom-20 left-10 w-56 h-56 bg-brand-green/5 rounded-full blur-2xl -z-10"></div>
      
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Hero Text Section - Left Column */}
          <div className="order-2 lg:order-1">
            <div className={`space-y-5 transition-all duration-700 ${isVisible ? 'opacity-100' : 'opacity-0 translate-y-10'}`}>
              <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium">
                При поддержке корпорации МСП и Минэкономразвития РФ
              </span>
              
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-gray-900 leading-tight">
                Сократите расходы на digital-услуги — 
                <span className="text-brand-blue"> до 50% вернет государство</span>
              </h1>
              
              <p className="text-gray-600 text-base md:text-lg max-w-xl">
                Помогаем малому и среднему бизнесу, самозанятым и физлицам получать современные digital-услуги с компенсацией затрат через госпрограммы.
              </p>
              
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 pt-2">
                <Input
                  type="tel"
                  placeholder="Ваш номер телефона"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="h-11"
                />
                <Button 
                  type="submit"
                  className="bg-brand-blue hover:bg-brand-blue/90 text-white h-11 whitespace-nowrap"
                >
                  Получить консультацию
                </Button>
              </form>
              
              <p className="text-xs text-gray-500">
                Нажимая на кнопку, вы соглашаетесь на сбор и обработку персональных данных
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  asChild
                  variant="outline" 
                  className="border-brand-blue text-brand-blue hover:bg-brand-blue/10 h-11 text-base"
                >
                  <Link to="/for-clients">
                    Я ищу услуги для бизнеса
                  </Link>
                </Button>
                <Button 
                  asChild
                  variant="outline" 
                  className="border-brand-green text-brand-green hover:bg-brand-green/10 h-11 text-base"
                >
                  <Link to="/for-contractors" className="flex items-center">
                    Я хочу стать исполнителем
                    <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-gray-600 pt-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-brand-green h-4 w-4 flex-shrink-0" />
                  <span>Подходит для ИП и ООО со статусом МСП</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-brand-green h-4 w-4 flex-shrink-0" />
                  <span>Доступна поддержка для самозанятых и физлиц</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-brand-green h-4 w-4 flex-shrink-0" />
                  <span>Компенсация включена в стоимость услуг</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-brand-green h-4 w-4 flex-shrink-0" />
                  <span>Возможен налоговый вычет для юр. лиц</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* How It Works - Right Column */}
          <div className="order-1 lg:order-2">
            <div className="relative glass-card rounded-xl p-6 md:p-8 w-full max-w-md mx-auto animate-fade-in">
              <h3 className="text-lg font-semibold text-gray-900 mb-6 text-center">
                Как это работает
              </h3>
              
              <div className="relative">
                <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                
                {steps.map((step, index) => (
                  <div 
                    key={index} 
                    className={`relative pl-12 pb-8 last:pb-0 transition-all duration-500 ${
                      currentStep === index 
                        ? 'opacity-100' 
                        : 'opacity-50'
                    }`}
                  >
                    <div className={`absolute left-0 w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-500 ${
                      currentStep === index 
                        ? 'border-brand-blue bg-brand-blue text-white' 
                        : 'border-gray-300 bg-white text-gray-400'
                    }`}>
                      {index + 1}
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-1">{step.title}</h4>
                    <p className="text-sm text-gray-600">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
