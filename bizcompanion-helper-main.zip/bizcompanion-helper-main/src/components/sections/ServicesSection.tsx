
import { BrainCircuit, Lightbulb, LineChart, Target } from "lucide-react";
import ServiceCard from "@/components/ui/ServiceCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ServicesSection = () => {
  const services = [
    {
      id: "neuro-content",
      title: "Нейроконтент",
      description: "Автоматическая генерация постов, сторис и email-рассылок с помощью передовых нейросетей. Создавайте контент для соцсетей в 10 раз быстрее.",
      icon: <BrainCircuit className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 40,
      programName: "Цифровизация-2024",
      isPopular: true,
      marketPrice: "80 000 ₽",
    },
    {
      id: "ai-targeting",
      title: "AI-таргетинг",
      description: "Умная настройка и оптимизация рекламы в социальных сетях с аналитикой в реальном времени. Увеличьте ROAS ваших рекламных кампаний.",
      icon: <Target className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 30,
      programName: "МСП Технологии",
      isPopular: false,
      marketPrice: "65 000 ₽",
    },
    {
      id: "landing-pages",
      title: "Лендинги",
      description: "Создание высококонверсионных сайтов с AI-копирайтингом. Готовые шаблоны и быстрый запуск помогут привлечь новых клиентов.",
      icon: <Lightbulb className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 50,
      programName: "Инновации для бизнеса",
      isPopular: false,
      marketPrice: "100 000 ₽",
    },
    {
      id: "analytics",
      title: "Бизнес-аналитика",
      description: "Автоматический анализ данных вашего бизнеса с помощью ИИ. Получайте инсайты и рекомендации для принятия важных решений.",
      icon: <LineChart className="w-10 h-10 text-brand-blue" />,
      compensationPercent: 45,
      programName: "МСП Технологии",
      isPopular: false,
      marketPrice: "90 000 ₽",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white" id="services">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 rounded-full bg-brand-blue/10 text-brand-blue text-sm font-medium mb-4">
            Наши услуги
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            AI-решения для вашего бизнеса
          </h2>
          <p className="text-gray-600">
            Используйте современные технологии искусственного интеллекта для развития бизнеса и получайте компенсацию части затрат от государства. Доступен налоговый вычет для юридических лиц.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {services.map((service) => (
            <ServiceCard
              key={service.id}
              id={service.id}
              title={service.title}
              description={service.description}
              icon={service.icon}
              compensationPercent={service.compensationPercent}
              programName={service.programName}
              isPopular={service.isPopular}
              marketPrice={service.marketPrice}
            />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button 
            asChild
            variant="outline"
            className="bg-transparent"
          >
            <Link to="/services">
              Смотреть все услуги
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
