
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Services from "./pages/Services";
import AiServices from "./pages/AiServices";
import ServiceDetails from "./pages/ServiceDetails";
import Calculator from "./pages/Calculator";
import Chat from "./pages/Chat";
import NotFound from "./pages/NotFound";
import Packaging from "./pages/Packaging";
import Promotion from "./pages/Promotion";
import AiImplementation from "./pages/AiImplementation";
import OrgPlanning from "./pages/OrgPlanning";
import ForClients from "./pages/ForClients";
import ForContractors from "./pages/ForContractors";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/services" element={<Services />} />
          <Route path="/ai-services" element={<AiServices />} />
          <Route path="/services/:id" element={<ServiceDetails />} />
          <Route path="/calculator" element={<Calculator />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/packaging" element={<Packaging />} />
          <Route path="/promotion" element={<Promotion />} />
          <Route path="/ai-implementation" element={<AiImplementation />} />
          <Route path="/org-planning" element={<OrgPlanning />} />
          <Route path="/for-clients" element={<ForClients />} />
          <Route path="/for-contractors" element={<ForContractors />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
